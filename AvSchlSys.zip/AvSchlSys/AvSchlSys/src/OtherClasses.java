

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class OtherClasses
 */
@WebServlet("/OtherClasses")
public class OtherClasses extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OtherClasses() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession sess=request.getSession(false);
		String sid=(String)sess.getAttribute("sid");
		String classs=" ";
		int i=1;
		String[] co= {" "," ","second","third","fourth","fifth","sixth","seventh","eighth","nineth","tenth"," "};
		out.println("<html><body><center>");
		out.println("<h1><u>Students of This Class</u></h1>");
		out.println("<table border='1'><tr>");
		out.println("<th>S NO</th>");
		out.println("<th>STUDENT AADHAR</th>");
		out.println("<th>STUDENT NAME</th>");
		out.println("<th>VIEW</th></tr>");
		out.println("<form action='VerifyM' method='post'>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con0=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
		for(int j=2;j<co.length;j++)
		{
			classs=co[j];
			String pyr=" ",cyr=" ";
			String yr=" ";
			int yr0=0,yr1=0,c1=0,d=0;
			if(classs.equals(co[j]))
			{
				d=j;
				
			}
				Statement s0=con0.createStatement();
				ResultSet rs0=s0.executeQuery("select * from academic");
				while(rs0.next())
				{
					pyr=rs0.getString(2).substring(0,4);
					cyr=rs0.getString(1);
					pyr=pyr.substring(2,4);
					cyr=cyr.substring(2,4);
					yr0=Integer.parseInt(pyr);
					yr1=Integer.parseInt(cyr);
					for(int c=yr0;c<=yr1;c++)
					{
					yr="class_"+d+"_"+c;
					PreparedStatement ps=con1.prepareStatement("select * from "+yr+" where "+classs+" = ?");
					ps.setString(1,sid);
				   ResultSet rs1= ps.executeQuery();
				   while(rs1.next())
				   {
					   out.println("<tr><td>"+i+".</td>");
						out.println("<td>"+rs1.getString("saadhar")+"</td>");
						out.println("<td>"+rs1.getString("sname")+"</td>");
						out.println("<input type='hidden' name='classs' value='"+classs+"'>");
						out.println("<input type='hidden' name='table' value='"+yr+"'>");
						out.println("<td><button type='submit' style='background-color:'orange' 'color:black;' name='click' value='"+rs1.getString("scopy")+"'>CLICK</button></td></tr>");
					i++;
				   }
				   }
				}	
		}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		
		out.println("</form></table><center>");
		out.println("<br><br><br><button type='submit'><a href='verifyclass1.html' style='color:red;'>GO BACK</a></button>");
		   out.println("</center></body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
