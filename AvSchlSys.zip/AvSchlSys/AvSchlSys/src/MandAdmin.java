

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MandAdmin
 */
@WebServlet("/MandAdmin")
public class MandAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MandAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html><body><center>");
		HttpSession sess=request.getSession(false);	
	    String dist=(String)sess.getAttribute("dist");
		String mand=request.getParameter("mand");
		if(mand.equals("null"))
		{
			out.println("<h2>Error Selection of mandal</h2>");
			RequestDispatcher rd=request.getRequestDispatcher("AddMandAdmin");
			rd.include(request, response);
		}
		else
		{
		String[] mail=request.getParameterValues("mail");
		String[] ip1=request.getParameterValues("ip1");
		String[] ip2=request.getParameterValues("ip2");
		int k=0, i=1,t=1;
		String aid="",admid="";
		out.println("<html><body><center><h3>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Statement stmt=con.createStatement();
			ResultSet rs2=stmt.executeQuery("select * from "+dist);
			while(rs2.next())
			{
				if(rs2.getString(1).equals(mand))
				{
					String s=rs2.getString(1).toLowerCase();
					aid=aid+s.charAt(0)+s.charAt(1)+s.charAt(2);
					aid=aid+i;
					break;
				}
				else {
					i++;
			}
			}
			switch(dist)
			{
			case "Adilabad": admid="adl";
							 break;
			case "Bhadradri_Kothagudem": admid="bdd";
			 				 break;
			case "Hyderabad": admid="hyd";
			 				break;
			case "Jagtial": admid="jgl";
			 				break;
			case "Jangaon": admid="jgn";
			 				break;
			case "Jayashankar_Bhupalapally": admid="bpp";
			 				break;
			case "Jogulamba_Gadwal": admid="gdl";
			 				break;
			case "Kamareddy": admid="krd";
			 				break;
			case "Karimnagar": admid="kmr";
			 				break;
			case "Khammam": admid="kmm";
							break;
			case "Kumarambheem_Asifabad": admid="afd";
			 				break;
			case "Mahabubabad": admid="mbb";
			 				break;
			case "Mahabubnagar": admid="mbn";
			 				break;
			case "Mancherial": admid="mcl";
			 				break;
			 case "Medak": admid="mdk";
			 				break;
			case "Medchal_Malkajgiri": admid="mdc";
			 				break;
			case "Nagarkurnool": admid="nkl";
			 				break;
			case "Nalgonda": admid="ngd";
			 				break;
			case "Nirmal": admid="nml";
			 				break;
			case "Nizamabad": admid="nzd";
			 				break;
			case "Peddapalli": admid="ppl";
			 				break;
			case "Rajanna_Sircilla": admid="src";
			 				break;
			case "RangaReddy": admid="rrd";
			 				break;
			case "Sangareddy": admid="srd";
			 				break;
			case "Siddipet": admid="sdt";
			 				break;
			case "Suryapet": admid="spt";
			 				break;
			case "Vikarabad": admid="vkd";
			 				break;
			case "Wanaparthy": admid="wpy";
			 				break;
			case "Warangal_Urban": admid="wgu";
			 				break;
			case "Warangal_Rural": admid="wgr";
			 				break;
			case "Yadadri_Bhuvanagiri": admid="Ydd";
			 				break;
			}
			aid=aid+admid+"ad";
			for(int j=0;j<2;j++)
	        {
			PreparedStatement ps=con.prepareStatement("insert into admin values(?,?,?,?,?,?,?)");
			aid=aid+t;
			ps.setString(1,aid);
			t++;
			String Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	        StringBuilder ranstr = new StringBuilder();
	        Random rnd = new Random();
	        while (ranstr.length() <= 10) { // length of the random string.
	            int index = (int) (rnd.nextFloat() * Chars.length());
	            ranstr.append(Chars.charAt(index));
	        }
	        String Str = ranstr.toString();
	        ps.setString(2,Str);
	        ps.setString(3,dist);
	        ps.setString(4,mand);
	        ps.setString(5,mail[j]);
			ps.setString(6,ip1[j]);
			ps.setString(7,ip2[j]);
			k=k+ps.executeUpdate();
			String to=mail[j];
			String subject="To District admin, related mail from Mock Education Board ";
			Mail.sendm(to,subject,aid,Str);
			aid=aid.substring(0,aid.length()-1);
	        }
			if(k==1||k==2) {
			out.println(" Successfully "+k+"admins created<br><br>");
			out.println(" link has been sent successfully to mails with their id and password <br><br> ");
			}
		}

		catch(Exception e)
		{
			System.out.println(e);
		}
}
	}
}