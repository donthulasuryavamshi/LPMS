

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Academic
 */
@WebServlet("/Academic")
public class Academic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Academic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html><body><center><br><br><br><br><br><br><h2>");
		out.println("<script src='back.js'></script>");
		int k=0,yr1=0,c=2;
		String currdate=null;
		String mon="",yr=" ",yr2="class_",yr3=" ",yr0=" ",yer=" ";
		String[] district= {"Adilabad","Bhadradri_Kothagudem","Hyderabad","Jagtial","Jangaon","Jayashankar_Bhoopalpally","Jogulamba_Gadwal","Kamareddy","Karimnagar","Khammam","KomaramBheem_Asifabad","Mahabubabad","Mahabubnagar","Mancherial","Medchal","Medak","Nagarkurnool","Nalgonda","Nirmal","Nizamabad","Peddapalle","Rajanna_Sircilla","RangaReddy","Sangareddy","Siddipet","Suryapet","Vikarabad","Wanaparthy","Warangal_Rural","Warangal_Urban","Yadadri_Bhuvanagiri"};
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con0=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			Connection con3=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Statement s0=con0.createStatement();
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/verifiedstud","root","");
			Statement s1=con1.createStatement();
			Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/rejectedstud","root","");
			Statement s2=con2.createStatement();
			PreparedStatement ps4=con0.prepareStatement("select CURRENT_DATE");
			ResultSet rs4=ps4.executeQuery();
			while(rs4.next())
			{
				currdate=rs4.getString(1);
				mon=currdate.substring(5,7);//0000-00-00
				yr=currdate.substring(0,4);
				yr0=currdate.substring(2,4);
				yr1=Integer.parseInt(yr);
				yr1++;
				yr="_"+yr+"_"+yr1;
				yr3=yr2+c+++"_"+yr0;	
			}
			for(int i=0;i<district.length;i++)
			{
				k=k+s0.executeUpdate("CREATE TABLE "+district[i]+yr+"(saadhar varchar(12),sname varchar(100),sfname varchar(100),scaste varchar(5),smob varchar(12),smail varchar(100),scopy varchar(200),first varchar(15),second varchar(15),third varchar(15),fourth varchar(15),fifth varchar(15),sixth varchar(15),seventh varchar(15),eighth varchar(15),nineth varchar(15),tenth varchar(15),PRIMARY KEY(saadhar));");
				k=k+s1.executeUpdate("CREATE TABLE "+district[i]+yr+"(saadhar varchar(12),sname varchar(100),sfname varchar(100),scaste varchar(5),smob varchar(12),smail varchar(100),scopy varchar(200),first varchar(15),percent-1 int(5),second varchar(15),percent-2 int(5),third varchar(15),percent-3 int(5),fourth varchar(15),percent-4 int(5),fifth varchar(15),percent-5 int(5),sixth varchar(15),percent-6 int(5),seventh varchar(15),percent-7 int(5),eighth varchar(15),percent-8 int(5),nineth varchar(15),percent-9 int(5),tenth varchar(15),percent-10 int(5),PRIMARY KEY(saadhar));");
				k=k+s2.executeUpdate("CREATE TABLE "+district[i]+yr+" (saadhar varchar(12),sname varchar(100),sclass varchar(15),sfname varchar(100),scaste varchar(5),smob varchar(12),smail varchar(100),scopy varchar(200),schlid varchar(10),reason varchar(300));");
			}
			HttpSession session=request.getSession(false);
			String a=session.getAttribute("yr").toString();
			int year=Integer.parseInt(a);
			PreparedStatement ps1=con3.prepareStatement("update academic set year='"+year+"' where date=?;");
			ps1.setString(1,"2018-07-07");
			k=k+ps1.executeUpdate();
			session.removeAttribute(yr);
				/*k=s0.executeUpdate("CREATE TABLE "+yr+"(saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),first varchar(10),PRIMARY KEY(saadhar));");
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),second varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+"(saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),third varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),fourth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),fifth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),sixth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),seventh varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),eighth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),nineth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s0.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),tenth varchar(10),PRIMARY KEY(saadhar));");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/verifiedstud","root","");
			Statement s1=con1.createStatement();
			k=k+s1.executeUpdate("CREATE TABLE "+yr+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),first varchar(10),PRIMARY KEY(saadhar));");
			c=2;
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),second varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+"(saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),third varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),fourth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),fifth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),sixth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),seventh varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),eighth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),nineth varchar(10),PRIMARY KEY(saadhar));");
			yr3=yr2+c+++"_"+yr0;
			k=k+s1.executeUpdate("CREATE TABLE "+yr3+" (saadhar varchar(12),sname varchar(100),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),tenth varchar(10),PRIMARY KEY(saadhar));");
		
			Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/rejectedstud","root","");
			Statement s2=con2.createStatement();
			k=k+s2.executeUpdate("CREATE TABLE "+yr+" (saadhar varchar(12),sname varchar(100),sclass varchar(10),sfname varchar(100),smob varchar(12),smail varchar(100),scopy varchar(200),schlid varchar(10),reason varchar(300));");
			
			HttpSession session=request.getSession(false);
			String a=session.getAttribute("yr").toString();
			int year=Integer.parseInt(a);
			PreparedStatement ps1=con3.prepareStatement("update academic set year='"+year+"' where date=?;");
			ps1.setString(1,"2018-07-07");
			k=k+ps1.executeUpdate();
			session.removeAttribute(yr);*/
			con0.close();
			con1.close();
			con2.close();
			con3.close();
		}
		
		catch(Exception e)
		{
			System.out.print(e);
		}
		if(k==1)
		{
			out.println("successfully new academic year enabled<br><br>");
			out.println("<button type='submit'><a href='AdmSuper.html' style='color:green;'>GO BACK</a></button>");
		}
		else
		{
			out.println("unsuccessfull new academic enabled<br><br>");
			out.println("<button type='submit'><a href='NewAcademic' style='color:red;'>TRY AGAIN</a></button>");
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
