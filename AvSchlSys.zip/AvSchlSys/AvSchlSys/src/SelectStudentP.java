

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SelectStudentP
 */
@WebServlet("/SelectStudentP")
public class SelectStudentP extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectStudentP() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession sess=request.getSession(false);
		String sid=(String)sess.getAttribute("sid");
		String classs=request.getParameter("sclass");
		sess.setAttribute("cla",classs);
		String pyr=" ",cyr=" ";
		String yr=" ";
		int date=0,kyr=0;
		int yr0=0,yr1=0,c1=0,i=1,d=0;
		out.println("<html><body><center>");
		out.println("<h1><u>Students of This Class</u></h1>");
		out.println("<table border='1'><tr>");
		out.println("<th>S NO</th>");
		out.println("<th>STUDENT AADHAR</th>");
		out.println("<th>STUDENT NAME</th>");
		out.println("<th>ACTION-1</th>");
		out.println("<th>ACTION-2</th></tr>");
		out.println("<form action=' ' method='post'>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con0=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			Statement s0=con0.createStatement();
			ResultSet rs0=s0.executeQuery("select creation from schooldetails");
			ResultSet rs5=s0.executeQuery("select year from academic");
			while(rs0.next())
			{
				DateFormat dateFormat = new SimpleDateFormat("yyyy");
				date=Integer.parseInt(dateFormat.format(rs0.getDate(1)));
			}
			if(classs.equals("first"))
			{
				while(rs5.next())
				{
					kyr=Integer.parseInt(rs5.getString(1));
				}
				while(date==kyr)
				{
				yr="yr"+date+"_"+date++;
			PreparedStatement ps=con1.prepareStatement("select * from "+yr+" where first=?");
			ps.setString(1,sid);
		   ResultSet rs1= ps.executeQuery();
		   while(rs1.next())
		   {
			   out.println("<tr><td>"+i+++".</td>");
				out.println("<td>"+rs1.getString("saadhar")+"</td>");
				out.println("<td>"+rs1.getString("sname")+"</td>");
				out.println("<input type='hidden' name='table' value='"+yr+"'>");
				out.println("<td><button type='submit' formaction='Promote' style='background-color:'orange' 'color:black;' name='action' value='"+rs1.getString("saadhar")+"'>PROMOTE</button></td>");
				out.println("<td><button type='submit' formaction='Demote' style='background-color:'orange' 'color:black;' name='action' value='"+rs1.getString("saadhar")+"'>DEMOTE</button></td></tr>");
			}
		   }
			}
			else
			{
				String[] co= {" "," ","second","third","fourth","fifth","sixth","seventh","eighth","nineth","tenth"," "};
				for(int j=2;j<co.length;j++)
				{
					if(classs.equals(co[j]))
					{
						d=j;
						
					}
				}
				pyr=pyr.substring(2,4);
				cyr=cyr.substring(2,4);
				yr0=Integer.parseInt(pyr);
				yr1=Integer.parseInt(cyr);
				for(int c=yr0;c<=yr1;c++)
				{
				yr="class_"+d+"_"+c;
				PreparedStatement ps=con1.prepareStatement("select * from "+yr+" where "+classs+" = ?");
				ps.setString(1,sid);
			   ResultSet rs1= ps.executeQuery();
			   while(rs1.next())
			   {
				   out.println("<tr><td>"+i+++".</td>");
					out.println("<td>"+rs1.getString("saadhar")+"</td>");
					out.println("<td>"+rs1.getString("sname")+"</td>");
					out.println("<input type='hidden' name='table' value='"+yr+"'>");
					out.println("<td><button type='submit' style='background-color:'orange' 'color:black;' name='click' value='"+rs1.getString("scopy")+"'>CLICK</button></td></tr>");
				}
			   }
			}		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		out.println("</form></table><center>");
		out.println("<br><br><br><button type='submit'><a href='verifyclasses.html' style='color:red;'>GO BACK</a></button>");
		   out.println("</center></body></html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
