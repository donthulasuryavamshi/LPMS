

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ChangePassSchl
 */
@WebServlet("/ChangePassSchl")
public class ChangePassSchl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePassSchl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession sess=request.getSession(false);
	    String id=(String)sess.getAttribute("id");
	    String old=request.getParameter("old");
	    String newp=request.getParameter("new");
	    String confirm=request.getParameter("confirm");
	    String send=request.getParameter("action");
	    out.println("<html><body><center><h2>");
	    out.println("<script src='back.js'></script>");
	    int k=0;
		try {
			if(newp.equals(confirm))
			{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			if(send.equals("school"))
			{
			PreparedStatement stmt1=con.prepareStatement("select spwd from schooldetails where sid=?");
			stmt1.setString(1,id);
			ResultSet rs1=stmt1.executeQuery();
			while(rs1.next())
			{
				if(rs1.getString(1).equals(old))
				{
					k=-1;
				}
			}
			if(k==-1)
			{
			PreparedStatement stmt=con.prepareStatement("update schooldetails  set spwd=? where sid=?");
			stmt.setString(1,newp);
			stmt.setString(2,id);
			k=stmt.executeUpdate();
			out.println("Password changed successfully<br><br>");
			out.println("<a href='schoollogin.html'>LOGIN VERIFY</a>");
			}
			else
			{
				out.println("Old password didnt match with the logged in account<br><br>");
			}
			if(k==0)
			{
				out.println("Password didnt change.May Be Invalid Details");
			}
			}
			if(send.equals("admin"))
			{
				PreparedStatement stmt1=con.prepareStatement("select password from admin where admid=?");
				stmt1.setString(1,id);
				ResultSet rs1=stmt1.executeQuery();
				while(rs1.next())
				{
					if(rs1.getString(1).equals(old))
					{
						k=-1;
					}
				}
				if(k==-1)
				{
				PreparedStatement stmt=con.prepareStatement("update admin  set password=? where admid=?");
				stmt.setString(1,newp);
				stmt.setString(2,id);
				k=stmt.executeUpdate();
				out.println("Password changed successfully<br><br>");
				out.println("<a href='AdminLogin.html'>LOGIN VERIFY</a>");
				}
				else
				{
					out.println("Old password didnt match with the logged in account");
				}
				}
			}
			else
			{
				out.println("New Password and Confirm Password didnt match<br><br>");
			}
			if(k==0)
			{
				out.println("Password didnt change.May Be Invalid Details");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}