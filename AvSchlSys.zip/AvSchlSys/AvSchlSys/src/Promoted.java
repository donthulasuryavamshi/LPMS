import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Promoted
 */
@WebServlet("/Promoted")
public class Promoted extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Promoted() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//HttpSession sess=request.getSession(false);
		//String sid=(String)sess.getAttribute("id");
		String yr=request.getParameter("table");
		String classs=request.getParameter("sclass");
		String marks=request.getParameter("marks");
		String action=request.getParameter("action");
		out.println("<html><body><center><h2>");
		int k=0,m=0,pyr=0;
		String name="",clasp="",cyr="";
		/*try {
			String[] co= {" ","first","second","third","fourth","fifth","sixth","seventh","eighth","nineth","tenth"," "};
			for(int j=1;j<co.length;)
			{
				if(classs.equals(co[j]))
				{
					m=j;
					clasp=co[j];
					classs=co[++j];
					
				}
			
		}
			out.println(m);
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/verifiedstud","root","");
			PreparedStatement ps4=con1.prepareStatement("select CURRENT_DATE");
			ResultSet rs4=ps4.executeQuery();
			while(rs4.next())
			{
				cyr=rs4.getString(1);
				pyr=Integer.parseInt(cyr.substring(2,4));
			}
			if(classs.equals("tenth"))
			{
				PreparedStatement ps1=con1.prepareStatement("update "+yr+" set percent-"+m+"=? where saadhar=?");
				ps1.setString(1,marks);
				ps1.setString(2,action);
				k=ps1.executeUpdate();
			}
			else
			{
			PreparedStatement ps1=con1.prepareStatement("update "+yr+" set percent-"+m+"=? ,"+classs+"=? ,"+clasp+"= ? where saadhar=?");
			ps1.setString(1,marks);
			ps1.setString(2,sid+pyr);
			ps1.setString(3,action);
			k=ps1.executeUpdate();
		}
			Statement s=con1.createStatement();
			ResultSet rs=s.executeQuery("select sname from "+yr);
			while(rs.next())
				name=rs.getString(1);
			if(marks != null && !marks.isEmpty())
			{
				PreparedStatement ps1=con1.prepareStatement("update "+yr+" set percent-"+m+"=0 ,"+clasp+"= ? where saadhar=?");
				ps1.setString(1,marks);
				ps1.setString(2,sid+pyr);
				ps1.setString(3,action);
				k=ps1.executeUpdate();
			}
			con1.close();
		}
		catch(Exception e)
		{
			out.println(e);
		}
		if(k==1)
		{
			out.println(name+" is successfully promoted.<br><br>");
		}
		else
			out.println("unsuccessfull promotion");*/
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
