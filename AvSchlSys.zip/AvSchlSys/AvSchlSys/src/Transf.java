

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Transf
 */
@WebServlet("/Transf")
public class Transf extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Transf() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String action=request.getParameter("action");
		out.println("<html> <head> <link rel='stylesheet' type='text/css' href='index.css'> <meta charset='ISO-8859-1'> <style><link rel='stylesheet' type='text/css' href='index.css'<style>body{background-color:powder-blue;border-left: 15px solid orange;border-right: 15px solid orange;border-top: 15px solid orange;border-radius:30px;}.topnav {background-color: #333;overflow: hidden;width:99%;}.topnav a {float: left;display: block;"+
				" color: #f1f1f1; text-align: center; padding: 10px 12px;text-decoration: none;font-size: 20px;} .footer {position:absolute;left:0;bottom: 0;width:100%;background-color:none;color:green;text-align: center;height: 100px;}.active {background-color:gray;color: white;}.topnav .icon {display: none;}.dropdown {float: left;overflow: hidden;}.dropdown .dropbtn {font-size: 17px; border: none;outline: none;color: white;padding: 14px 16px;background-color: inherit;font-family: inherit;margin: 0;}.dropdown-content {display: none;position: absolute;background-color: #f9f9f9;min-width: 160px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);"+
				 "z-index: 1;}.dropdown-content a {float: none;color: black;padding: 12px 16px;text-decoration: none;display: block;text-align: left;}.topnav a:hover, .dropdown:hover .dropbtn {background-color: #555;color: white;}.dropdown-content a:hover {"+
				   "background-color: #ddd;color: black;}.dropdown:hover .dropdown-content {display: block;}@media screen and (max-width: 600px) {.topnav a:not(:first-child), .dropdown .dropbtn {display: none;}.topnav a.icon {float: right;display: block;}}@media screen and (max-width: 600px) {.topnav.responsive {position: relative;}.topnav.responsive a.icon {position: absolute;right: 0;top: 0;}.topnav.responsive a {float: none;display: block;text-align: left;}.topnav.responsive .dropdown {float:none;}.topnav.responsive .dropdown-content {position: relative;}.topnav.responsive .dropdown .dropbtn {display: block;width: 100%;text-align: left;}}</style></head><body><div class='logo'><img src='logo1-2.jpg' class='img-circle' alt='symbol'>&nbsp;&nbsp;&nbsp;&nbsp;<center><font size='5' color='black'><i><b>ADVANCED SCHOOLING SYSTEM</i></b></font></center></div><div class='topnav' id='myTopnav'><a href='#home' class='active'>Home</a><a href='#news'>About</a></div><center><h2 color='black'>");
		
		if(action.equals("TRA"))
		{
			out.println("transfer requested");
		}
		else {
		out.println("<center><br><br><br>NOT READY TO TRANSFER.<br>");
		out.println("<br>UPDATE PERFORMANCE.<br>");
		}	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
