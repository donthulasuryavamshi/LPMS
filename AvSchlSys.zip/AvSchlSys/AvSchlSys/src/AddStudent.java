

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AddStudent
 */
@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter(); 
		HttpSession sess=request.getSession(false);	
	    String id=(String)sess.getAttribute("id");
	    String file=(String)sess.getAttribute("sfile");
	    String name=request.getParameter("sname");
	    String sclass=request.getParameter("sclass");
	    String scaste=request.getParameter("scaste");
	    String aadhar=request.getParameter("aadhar");
	    sess.setAttribute("aad",aadhar);
	    sess.setAttribute("cla",sclass);
	    String mail=request.getParameter("email");
	    String fname=request.getParameter("fname");
	    String mobile=request.getParameter("mobile");
	    String page=request.getParameter("action");
	    out.println("<html><body><center><h2>");
	    int a=1;
	    int k=0,yr1=0,c=2;
		String currdate=null;
		String mon="",yr=" ",yr2="class_",yr3=" ",yr0=" ";
	    try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select aadhar,name,sid from linkstudent");
			while(rs.next())
			{
				a=0;
				if(aadhar.equals(rs.getString(1)))
				{
					if(name.equals(rs.getString(2)))
					{
						if(id.equals(rs.getString(3)))
						{
						out.println("Student is already registered from your school<br>");
						}
						else
						{
						out.println("<br>Student is already registered from other school with school id-"+rs.getString(3)+".<br>");
						}
					}
					else
					{
						out.println("<br>AADHAR NUMBER is already registered. May be entered wrong check");
					}
					
				}
				else
				{
					a=1;
				}
				
			}
			
			if(a==1)
			{
				PreparedStatement stmt0=con.prepareStatement("select sdist from schooldetails where sid=?");
				stmt0.setString(1,id);
				ResultSet rs0=stmt0.executeQuery();
				while(rs0.next()) {
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			PreparedStatement ps4=con1.prepareStatement("select CURRENT_DATE");
			ResultSet rs4=ps4.executeQuery();
			while(rs4.next())
			{
				currdate=rs4.getString(1);
				mon=currdate.substring(5,7);//0000-00-00
				yr=currdate.substring(0,4);
				yr0=currdate.substring(2,4);
				yr1=Integer.parseInt(yr);
				yr1++;
				yr="_"+yr+"_"+yr1;
			}
			if(sclass.equals("first"))
			{ 
			PreparedStatement ps=con1.prepareStatement("insert into "+rs0.getString(1)+yr+" (saadhar,sname,sfname,scaste,smob,smail,scopy,first) values(?,?,?,?,?,?,?,?)");
			ps.setString(1,aadhar);
			ps.setString(2,name);
			ps.setString(3,fname);
			ps.setString(4,scaste);
			ps.setString(5,mobile);
			ps.setString(6,mail);
			ps.setString(7,file);
			ps.setString(8,id+yr0);
			k=ps.executeUpdate();
			}
			else
			{
			String[] co= {" "," ","second","third","fourth","fifth","sixth","seventh","eighth","nineth","tenth"," "};
			for(int j=2;j<co.length;j++)
			{
				if(sclass.equals(co[j]))
				{
					mon=co[j];
				}
			}
			yr3=yr2+c+"_"+yr0;
			PreparedStatement ps1=con1.prepareStatement("insert into "+rs0.getString(1)+yr+"(saadhar,sname,sfname,scaste,smob,smail,scopy,"+mon+") values(?,?,?,?,?,?,?,?)");
			ps1.setString(1,aadhar);
			ps1.setString(2,name);
			ps1.setString(3,fname);
			ps1.setString(4,scaste);
			ps1.setString(5,mobile);
			ps1.setString(6,mail);
			ps1.setString(7,file);
			ps1.setString(8,id+yr0);
			k=ps1.executeUpdate();
			}
			PreparedStatement ps2=con.prepareStatement("insert into linkstudent values(?,?,?)");
			ps2.setString(1,aadhar);
			ps2.setString(2,name);
			ps2.setString(3,id);
			k=k+ps2.executeUpdate();

			if(k==2)
			{
				 out.println(" Successfully Requested<br><br>");
				 if(page.equals("addstudent")) {
    				 out.println("<button type='submit'><a href='addstudent.html' style='color:green;'>ADD  MORE</a></button>&nbsp;&nbsp;&nbsp;");
    				 out.println("<button type='submit'><a href='SchoolHome' style='color:blue;'>HOME</a></button>");
 }
    				 else
    				 {
	 out.println("<button type='submit'><a href='addclass1.html' style='color:green;'>ADD  MORE</a></button>&nbsp;&nbsp;&nbsp;");
	 out.println("<button type='submit'><a href='SchoolHome' style='color:blue;'>HOME</a></button>");
}
    				 }
			
			else
			{
				out.println("<br>Error in Applying.Try Again<br>");
				out.println("<button type='submit'><a href='addstudent.html' style='color:red;'>TRY AGAIN</a></button>");
			}
		}
		}
		}
	    catch(Exception e)
	    {
	    	System.out.println(e);
	    	out.println("<center><h2>ALREADY INSERTED-DUPLICATE ENTRY</center> ");
	    }

}
}