

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DistAdmin
 */
@WebServlet("/DistAdmin")
public class DistAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DistAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html> <head> <link rel='stylesheet' type='text/css' href='index.css'> <meta charset='ISO-8859-1'> <style><link rel='stylesheet' type='text/css' href='index.css'<style>body{background-color:powder-blue;border-left: 15px solid orange;border-right: 15px solid orange;border-top: 15px solid orange;border-radius:30px;}.topnav {background-color: #333;overflow: hidden;width:99%;}.topnav a {float: left;display: block;"+
		" color: #f1f1f1; text-align: center; padding: 10px 12px;text-decoration: none;font-size: 20px;} .footer {position:absolute;left:0;bottom: 0;width:100%;background-color:none;color:green;text-align: center;height: 100px;}.active {background-color:gray;color: white;}.topnav .icon {display: none;}.dropdown {float: left;overflow: hidden;}.dropdown .dropbtn {font-size: 17px; border: none;outline: none;color: white;padding: 14px 16px;background-color: inherit;font-family: inherit;margin: 0;}.dropdown-content {display: none;position: absolute;background-color: #f9f9f9;min-width: 160px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);"+
		 "z-index: 1;}.dropdown-content a {float: none;color: black;padding: 12px 16px;text-decoration: none;display: block;text-align: left;}.topnav a:hover, .dropdown:hover .dropbtn {background-color: #555;color: white;}.dropdown-content a:hover {"+
		   "background-color: #ddd;color: black;}.dropdown:hover .dropdown-content {display: block;}@media screen and (max-width: 600px) {.topnav a:not(:first-child), .dropdown .dropbtn {display: none;}.topnav a.icon {float: right;display: block;}}@media screen and (max-width: 600px) {.topnav.responsive {position: relative;}.topnav.responsive a.icon {position: absolute;right: 0;top: 0;}.topnav.responsive a {float: none;display: block;text-align: left;}.topnav.responsive .dropdown {float:none;}.topnav.responsive .dropdown-content {position: relative;}.topnav.responsive .dropdown .dropbtn {display: block;width: 100%;text-align: left;}}</style></head><body><div class='logo'><img src='logo1-2.jpg' class='img-circle' alt='symbol'>&nbsp;&nbsp;&nbsp;&nbsp;<center><font size='5' color='black'><i><b>ADVANCED SCHOOLING SYSTEM</i></b></font></center></div><div class='topnav' id='myTopnav'><a href='#home' class='active'>Home</a><a href='#news'>About</a></div><center><h2 color='black'>");
		//RequestDispatcher rd=request.getRequestDispatcher("Home.html");
		//rd.include(request, response);
			//	PrintWriter out=response.getWriter();
		String dist=request.getParameter("dist");
		String mail=request.getParameter("mail");
		String ip1=request.getParameter("ip1");
		String ip2=request.getParameter("ip2");
		if(ip2==" ")
		{
			ip2=null;
		}
		int k=0;
		String admid="";
		switch(dist)
		{
		case "Adilabad": admid="adl";
						 break;
		case "Bhadradri_Kothagudem": admid="bdd";
		 				 break;
		case "Hyderabad": admid="hyd";
		 				break;
		case "Jagtial": admid="jgl";
		 				break;
		case "Jangaon": admid="jgn";
		 				break;
		case "Jayashankar_Bhupalapally": admid="bpp";
		 				break;
		case "Jogulamba_Gadwal": admid="gdl";
		 				break;
		case "Kamareddy": admid="krd";
		 				break;
		case "Karimnagar": admid="kmr";
		 				break;
		case "Khammam": admid="kmm";
						break;
		case "Kumarambheem_Asifabad": admid="afd";
		 				break;
		case "Mahabubabad": admid="mbb";
		 				break;
		case "Mahabubnagar": admid="mbn";
		 				break;
		case "Mancherial": admid="mcl";
		 				break;
		 case "Medak": admid="mdk";
		 				break;
		case "Medchal_Malkajgiri": admid="mdc";
		 				break;
		case "Nagarkurnool": admid="nkl";
		 				break;
		case "Nalgonda": admid="ngd";
		 				break;
		case "Nirmal": admid="nml";
		 				break;
		case "Nizamabad": admid="nzd";
		 				break;
		case "Peddapalli": admid="ppl";
		 				break;
		case "Rajanna_Sircilla": admid="src";
		 				break;
		case "RangaReddy": admid="rrd";
		 				break;
		case "Sangareddy": admid="srd";
		 				break;
		case "Siddipet": admid="sdt";
		 				break;
		case "Suryapet": admid="spt";
		 				break;
		case "Vikarabad": admid="vkd";
		 				break;
		case "Wanaparthy": admid="wpy";
		 				break;
		case "Warangal_Urban": admid="wgu";
		 				break;
		case "Warangal_Rural": admid="wgr";
		 				break;
		case "Yadadri_Bhuvanagiri": admid="Ydd";
		 				break;
		}
		admid=admid+"adm";
		out.println("<h3>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			PreparedStatement ps=con.prepareStatement("insert into admin values(?,?,?,?,?,?,?)");
			ps.setString(1,admid);
			String Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	        StringBuilder ranstr = new StringBuilder();
	        Random rnd = new Random();
	        while (ranstr.length() <= 10) { // length of the random string.
	            int index = (int) (rnd.nextFloat() * Chars.length());
	            ranstr.append(Chars.charAt(index));
	        }
	        String Str = ranstr.toString();
			ps.setString(2,Str);
			ps.setString(3,dist);
			ps.setString(4,null);
			ps.setString(5,mail);
			ps.setString(6,ip1);
			ps.setString(7,ip2);
			k=ps.executeUpdate();
			out.println(" Successfully admin created<br><br>");
			String to=mail;
			String subject="To District admin, related mail from Mock Education Board ";
			Mail.sendd(to,subject,admid,Str);
			out.println(" link has been sent successfully to mails with their id and password <br><br> ");

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			if(k!=0)
				{
					out.println("<a href='AddDistAdm.html'>ADD MORE</a>");
					out.println("<a href='AdmSuper.html'>BACK</a>");
				}
			else
			{
			out.println("ERROR in creating<br><br>");	
			out.println("<a href='AddDistAdm.html'>TRY AGAIN</a>");
			}
			out.println("<div class='footer'><p align='center'><font size='5' >PLANT A TREE</font> </p></div>");
			out.println("</h2></center></body></html>");
}


	}


