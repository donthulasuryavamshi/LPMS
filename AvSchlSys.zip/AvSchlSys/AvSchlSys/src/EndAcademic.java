

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EndAcademic
 */
@WebServlet("/EndAcademic")
public class EndAcademic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EndAcademic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String currdate=null;
		String mon="";
		int yr1=0,yr=0,ch=0;
		out.println("<html><body><center><br><br><br><br><br><br><h2>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			PreparedStatement ps3=con.prepareStatement("select eyear from academic");
			ResultSet rs3=ps3.executeQuery();
			while(rs3.next())
			{
				yr=rs3.getInt(1)+1;
			}
		PreparedStatement ps4=con.prepareStatement("select CURRENT_DATE");
		ResultSet rs4=ps4.executeQuery();
		while(rs4.next())
		{
			currdate=rs4.getString(1);
			mon=currdate.substring(5,7);//0000-00-00
			yr1=Integer.parseInt(currdate.substring(0,4));
		}
		if((mon.equals("05")||mon.equals("06"))&&yr1==yr)
		{
			out.println("End Academic Year is  available click below: <br><br>");
			HttpSession session=request.getSession(false);
			session.setAttribute("yr",yr);
			ch=1;
			out.println("<button type='submit'><a href='EAcademic' style='color:green;'>ENABLE</a></button>");
			out.println("<button type='submit' style='color:red;'><a href='AdmSuper.html' style='color:red;'>CANCEL</a></button>");
		}
		else if((mon.equals("05")||mon.equals("06"))&&yr1==yr-1)
		{
			out.println("This Academic Year ("+yr1+") is already ended and performance can be updated<br><br>");
			out.println("<button type='submit' style='color:red;'><a href='AdmSuper.html' style='color:red;'>GO BACK</a></button>");

		}
		else
		{
			out.println("End Academic Year is not available to enable<br><br> ");
			out.println("<button type='submit' style='color:red;'><a href='AdmSuper.html' style='color:red;'>GO BACK</a></button>");
		}
		}
			catch(Exception e)
		{
	System.out.println(e);
		}
		finally {
			if(ch!=1)
				out.println("<br><br><br><br><h3 style='color:red'>Error.RELOGIN PLZZZ<h3>");
		}
		out.println("</h2></center></body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
