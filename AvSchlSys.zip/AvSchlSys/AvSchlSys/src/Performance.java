

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Performance
 */
@WebServlet("/Performance")
public class Performance extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Performance() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String currdate=null;
		int mon=0;
		int yr1=0,yr=0,dy=00,yr2=0;
		out.println("<html><body><center><br><br><br><br><h2>");
		out.println("<script src='back.js'></script>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			PreparedStatement ps3=con.prepareStatement("select year,eyear from academic");
			ResultSet rs3=ps3.executeQuery();
			while(rs3.next())
			{
				yr=rs3.getInt(1);
				yr2=rs3.getInt(2);
				
			}
		PreparedStatement ps4=con.prepareStatement("select CURRENT_DATE");
		ResultSet rs4=ps4.executeQuery();
		while(rs4.next())
		{
			currdate=rs4.getString(1);
			dy=Integer.parseInt(currdate.substring(8,10));
			mon=Integer.parseInt(currdate.substring(5,7));//0000-00-00
			yr1=Integer.parseInt(currdate.substring(0,4));
		}
		if(yr1==yr2)
		{
			if(mon>=05&&dy>=00)
				{
					if(mon<=06&&dy<=15)
						{
							out.println("Performance enabled");
							response.sendRedirect("performance.html");
						}
					else
					{
						out.println("SESSION TO TAKE PERFORMANCE ENDED<br><h5>WRITE A REQUEST IN CASE OF NEED.</h5>");
						out.println("<button type='submit' style='background-color:orange; color:black'><a href='SchoolHome'>BACK</a></button>");
					}
				}
					else
					{
				out.println("WAIT TILL MAY");
				out.println("<br<br><br><button type='submit' style='background-color:orange; color:black'><a href='SchoolHome'>BACK</a></button>");
					}
			}
		else
		{
			out.println("YEAR NOT ENABLED OR ALREADY ENDED");
			out.println("<br<br><br><button type='submit' style='background-color:orange; color:black'><a href='SchoolHome'>BACK</a></button>");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
