

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EAcademic
 */
@WebServlet("/EAcademic")
public class EAcademic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EAcademic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html><body><center><br><br><br><br><br><br><h2>");
		out.println("<script src='back.js'></script>");
		int k=0,yr1=0,c=2;
		String currdate=null;
		String mon="",yr=" ",yr2="class_",yr3=" ",yr0=" ",yer=" ";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con3=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			HttpSession session=request.getSession(false);
			String a=session.getAttribute("yr").toString();
			int year=Integer.parseInt(a);
			PreparedStatement ps1=con3.prepareStatement("update academic set eyear='"+year+"' where date=?;");
			ps1.setString(1,"2018-07-07");
			k=ps1.executeUpdate();
			session.removeAttribute(yr);
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
		if(k==1)
		{
			out.println("successfully end academic year enabled<br><br>");
			out.println("<button type='submit'><a href='AdmSuper.html' style='color:green;'>GO BACK</a></button>");
		}
		else
		{
			out.println("unsuccessfull end academic enabled<br><br>");
			out.println("<button type='submit'><a href='EndAcademic' style='color:red;'>TRY AGAIN</a></button>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
