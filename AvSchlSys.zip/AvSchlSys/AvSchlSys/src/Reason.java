

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Reason
 */
@WebServlet("/Reason")
public class Reason extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Reason() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String sip2="";
		HttpSession sess=request.getSession(false);
		String sfile=(String)sess.getAttribute("sfile");
		out.println("<html><body><center>");
		out.println("<h1>Selected School Details</h1>");
		out.println("<table border='1'>");
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			PreparedStatement ps=con.prepareStatement("select * from unschooletails where sfile=?");
			ps.setString(1,sfile);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				out.println("<tr><td><b>SCHOOL NAME</b></td>");
				out.println("<td>"+rs.getString("sname")+"</td></tr>");
				out.println("<tr><td><b>TYPE</b></td>");
				out.println("<td>"+rs.getString("stype")+"</td></tr>");
				out.println("<tr><td><b>Till Classes</b></td>");
				out.println("<td>"+rs.getString("sclass")+"</td></tr>");
				out.println("<tr><td><b>DISTRICT</b></td>");
				out.println("<td>"+rs.getString("sdist")+"</td></tr>");
				out.println("<tr><td><b>MANDAL</b></td>");
				out.println("<td>"+rs.getString("smand")+"</td></tr>");
				out.println("<tr><td><b>ADDRESS</b></td>");
				out.println("<td>"+rs.getString("saddr")+"</td></tr>");
				out.println("<tr><td><b>NUMBER</b></td>");
				out.println("<td>"+rs.getString("snum")+"</td></tr>");
				out.println("<tr><td><b>EMAIL</b></td>");
				out.println("<td>"+rs.getString("smail")+"</td></tr>");
				out.println("<tr><td><b>IP ADDRESS-1</b></td>");
				out.println("<td>"+rs.getString("sip1")+"</td></tr>");
				out.println("<tr><td><b>IP ADDRESS-2</b></td>");
				out.println("<td>"+rs.getString("sip2")+"</td></tr>");
				out.println("<tr><td><b>FILE</b></td>");
				out.println("<td><a href='File_download'>AUTHORIZATION DOCUMENT</a></td></tr>");
				
			}
	}
catch(Exception e)
		{
	System.out.println(e);
		}
		out.println("</table>");
		out.println("</center>");
		out.println("</body></html>");
		RequestDispatcher rd1=request.getRequestDispatcher("Reason.html");
		rd1.include(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
