

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Declinestud
 */
@WebServlet("/Declinestud")
public class Declinestud extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Declinestud() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String reason=request.getParameter("reason");
		HttpSession sess=request.getSession(false);
		String aad=(String)sess.getAttribute("aad");
		String table=(String)sess.getAttribute("tab");
		String cla=(String)sess.getAttribute("cla");
		int year=(int)sess.getAttribute("year");
		out.println("<html><body><center>");
		int k=0;
		String pyr=" ",cyr=" ";
		String yr=" ";
		int yr0=0,yr1=0,c1=0,i=1,d=0;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con0=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/rejectedstud","root","");
			PreparedStatement ps=con1.prepareStatement("select * from "+table+" where saadhar=?");
			ps.setString(1,aad);
			PreparedStatement ps3=con1.prepareStatement("delete from "+table+" where saadhar=?");
			ps3.setString(1,aad);
			PreparedStatement ps0=con0.prepareStatement("delete from linkstudent where aadhar=?");
			ps0.setString(1,aad);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Statement s0=con0.createStatement();
				ResultSet rs0=s0.executeQuery("select * from academic");
				while(rs0.next())
				{
					pyr=rs0.getString(2).substring(0,4);
					cyr=rs0.getString(1);
				}
					yr0=Integer.parseInt(pyr);
					yr1=Integer.parseInt(cyr);
					for(int c=yr0;c<=yr1;c++)
					{
						c1=c+1;
						yr="yr"+c+"_"+c1;
				PreparedStatement ps1=con2.prepareStatement("insert into "+table+" values(?,?,?,?,?,?,?,?,?,?)");
		        ps1.setString(1,rs.getString("saadhar"));
				ps1.setString(2,rs.getString("sname"));
				ps1.setString(3,cla);
				ps1.setString(4,rs.getString("sfname"));
				ps1.setString(5,rs.getString("scaste"));
				ps1.setString(6,rs.getString("smob"));
				ps1.setString(7,rs.getString("smail"));
				ps1.setString(8,rs.getString("scopy"));
				ps1.setString(9,rs.getString(""+cla+""));
				ps1.setString(10,reason);
				k=ps1.executeUpdate();
				ps3.executeUpdate();
				ps0.executeUpdate();
				sess.removeAttribute("sfile");
				}
			
			if(k==0)
			{
				out.println("<h2>Error insertion.Try Again</h2><br><br>");
				out.println("<a href='Verify'>Try Again</a>");
			}
			else
			{
				out.println("<h2>Successfully rejected</h2><br><br>");
				if(year==0)
					out.println("<a href='SelectStudent'>VERIFY MORE</a>");
					else {
						out.println("<a href='verifyclass1.html'>VERIFY MORE</a>");
				out.println("<a href='SelectStudent'>VERIFY MORE</a>");
					}
		}
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
