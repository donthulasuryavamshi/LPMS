

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Decline
 */
@WebServlet("/Decline")
public class Decline extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Decline() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession sess=request.getSession(false);
		String sfile=(String)sess.getAttribute("sfile");
		String reas=request.getParameter("reason");
		out.println("<html><body><center>");
		int k=0,i=1,a=0;
		String admid="";//here admid is school id
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			PreparedStatement ps=con.prepareStatement("select * from unschooletails where sfile=?");
			ps.setString(1,sfile);
			PreparedStatement ps3=con.prepareStatement("delete from unschooletails where sfile=?");
			ps3.setString(1,sfile);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				PreparedStatement ps1=con.prepareStatement("insert into rejectedschl values(?,?,?,?,?,?,?,?,?,?,?,?)");
		        ps1.setString(1,rs.getString("sname"));
				ps1.setString(2,rs.getString("stype"));
				ps1.setString(3,rs.getString("sclass"));
				ps1.setString(4,rs.getString("sdist"));
				ps1.setString(5,rs.getString("smand"));
				ps1.setString(6,rs.getString("saddr"));
				ps1.setString(7,rs.getString("snum"));
				ps1.setString(8,rs.getString("smail"));
				ps1.setString(9,rs.getString("sip1"));
				ps1.setString(10,rs.getString("sip2"));
				ps1.setString(11,sfile);
				ps1.setString(12,reas);
				k=ps1.executeUpdate();
				String to=rs.getString(8);
				String subject="Rejection mail from Mock Education Board ";
				Mail.send(to,subject,reas);
				out.println("<br><br><br><h2>Mail has been sent successfully to inform rejection of school insertion.</h2><br><br><br>");
				ps3.executeUpdate();
				sess.removeAttribute("sfile");
				}
			if(k==0)
			{
				out.println("<h2>Error rejection.Try Again</h2><br><br>");
				out.println("<a href='RequestsOpen'>Try Again</a>");
			}
			else
			{
				out.println("<h2>Successfully rejected</h2><br><br>");
				out.println("<a href='RequestsSchool'>VERIFY MORE</a>");
			
		}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
			}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
