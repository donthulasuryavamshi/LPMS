

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Reasonstud
 */
@WebServlet("/Reasonstud")
public class Reasonstud extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Reasonstud() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession sess=request.getSession(false);
		String cla=(String)sess.getAttribute("cla");
		String table=(String)sess.getAttribute("tab");
		String file=(String)sess.getAttribute("sfile");
		out.println("<html><body><center>");
		out.println("<h1>Selected Student Details</h1>");
		out.println("<table border='1'>");
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			PreparedStatement ps=con.prepareStatement("select * from "+table+" where scopy=?");
			ps.setString(1,file);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				out.println("<tr><td><b>STUDENT NAME</b></td>");
				out.println("<td>"+rs.getString("sname")+"</td></tr>");
				out.println("<tr><td><b>AADHAR NUMBER</b></td>");
				out.println("<td>"+rs.getString("saadhar")+"</td></tr>");
				sess.setAttribute("aad",rs.getString("saadhar"));
				out.println("<tr><td><b>JOINING CLASS</b></td>");
				out.println("<td>"+cla+"</td></tr>");
				out.println("<tr><td><b>FATHER NAME</b></td>");
				out.println("<td>"+rs.getString("sfname")+"</td></tr>");
				out.println("<tr><td><b>MOBILE</b></td>");
				out.println("<td>"+rs.getString("smob")+"</td></tr>");
				out.println("<tr><td><b>EMAIL</b></td>");
				out.println("<td>"+rs.getString("smail")+"</td></tr>");
				out.println("<tr><td><b>FILE</b></td>");
				out.println("<td><a href='File_download'>AUTHORIZATION DOCUMENT</a></td></tr>");
				
			}
	}
catch(Exception e)
		{
	System.out.println(e);
		}
		out.println("</table>");
		out.println("</center>");
		out.println("</body></html>");
		RequestDispatcher rd1=request.getRequestDispatcher("Reasonstud.html");
		rd1.include(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
