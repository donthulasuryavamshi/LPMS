

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Verify
 */
@WebServlet("/Verify")
public class Verify extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Verify() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html> <head> <link rel='stylesheet' type='text/css' href='index.css'> <meta charset='ISO-8859-1'> <style><link rel='stylesheet' type='text/css' href='index.css'<style>body{background-color:#f2f2f2;border-left: 15px solid gray;border-right: 15px solid gray;border-top: 15px solid gray;border-radius:30px;}.topnav {background-color: #333;overflow: hidden;width:99%;}.topnav a {float: left;display: block;"+
				" color: #f1f1f1; text-align: center; padding: 10px 12px;text-decoration: none;font-size: 20px;} .footer {position:absolute;left:0;bottom: 0;width:100%;background-color:none;color:green;text-align: center;height: 100px;}.active {background-color:gray;color: white;}.topnav .icon {display: none;}.dropdown {float: left;overflow: hidden;}.dropdown .dropbtn {font-size: 17px; border: none;outline: none;color: white;padding: 14px 16px;background-color: inherit;font-family: inherit;margin: 0;}.dropdown-content {display: none;position: absolute;background-color: #f9f9f9;min-width: 160px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);"+
				 "z-index: 1;}.dropdown-content a {float: none;color: black;padding: 12px 16px;text-decoration: none;display: block;text-align: left;}.topnav a:hover, .dropdown:hover .dropbtn {background-color: #555;color: white;}.dropdown-content a:hover {"+
				   "background-color: #ddd;color: black;}.dropdown:hover .dropdown-content {display: block;}@media screen and (max-width: 600px) {.topnav a:not(:first-child), .dropdown .dropbtn {display: none;}.topnav a.icon {float: right;display: block;}}@media screen and (max-width: 600px) {.topnav.responsive {position: relative;}.topnav.responsive a.icon {position: absolute;right: 0;top: 0;}.topnav.responsive a {float: none;display: block;text-align: left;}.topnav.responsive .dropdown {float:none;}.topnav.responsive .dropdown-content {position: relative;}.topnav.responsive .dropdown .dropbtn {display: block;width: 100%;text-align: left;}} h3{ color:black;}"
				   + "img{float:left;}th{background-color:#b3ff99;color:blue;} td{color:black;}h3{color:black}a{color:brown}</style></style></head><body><center><font size='5' color='black'><i><b>ADVANCED SCHOOLING SYSTEM</i></b></font></center><div class='topnav' id='myTopnav'><img src='logo1-2.jpg' class='img-circle' alt='symbol' height='70'></img></a><a href='#home' class='active'>Home</a><a href='#news'>About</a></div><center><h2 color='black'>");
		String file=request.getParameter("click");
		String table=request.getParameter("table");
		HttpSession sess=request.getSession(false);
		sess.setAttribute("sfile",file);
		sess.setAttribute("tab",table);
		String cla=(String)sess.getAttribute("cla");
		if(!(cla!=null)) 
		{
			cla=request.getParameter("classs");
		}
		out.println("<html><body><center>");
		out.println("<h3>Selected Student Details</h3>");
		out.println("<table border='1'>");
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			PreparedStatement ps=con.prepareStatement("select * from "+table+" where scopy=?");
			ps.setString(1,file);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				out.println("<tr><td><b>STUDENT NAME</b></td>");
				out.println("<td>"+rs.getString("sname")+"</td></tr>");
				out.println("<tr><td><b>AADHAR NUMBER</b></td>");
				out.println("<td>"+rs.getString("saadhar")+"</td></tr>");
				sess.setAttribute("aad",rs.getString("saadhar"));
				out.println("<tr><td><b>JOINING CLASS</b></td>");
				out.println("<td>"+cla+"</td></tr>");
				out.println("<tr><td><b>CASTE</b></td>");
				out.println("<td>"+rs.getString("scaste")+"</td></tr>");
				out.println("<tr><td><b>FATHER NAME</b></td>");
				out.println("<td>"+rs.getString("sfname")+"</td></tr>");
				out.println("<tr><td><b>MOBILE</b></td>");
				out.println("<td>"+rs.getString("smob")+"</td></tr>");
				out.println("<tr><td><b>EMAIL</b></td>");
				out.println("<td>"+rs.getString("smail")+"</td></tr>");
				out.println("<tr><td><b>FILE</b></td>");
				out.println("<td><a href='File_download' style='color:brown'>AUTHORIZATION DOCUMENT</a></td></tr>");
				
			}
	}
catch(Exception e)
		{
	System.out.println(e);
		}
		out.println("</table>");
		out.println("<button type='submit'><a href='Actionstud' style='color:green;'>ACCEPT</a></button>");
		out.println("<button type='submit'><a href='Reasonstud' style='color:red;'>DECLINE</a></button><br><br>");
		out.println("</center>");
		out.println("</body></html>");
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html> <head> <link rel='stylesheet' type='text/css' href='index.css'> <meta charset='ISO-8859-1'> <style><link rel='stylesheet' type='text/css' href='index.css'<style>body{background-color:#f2f2f2;border-left: 15px solid gray;border-right: 15px solid gray;border-top: 15px solid gray;border-radius:30px;}.topnav {background-color: #333;overflow: hidden;width:99%;}.topnav a {float: left;display: block;"+
				" color: #f1f1f1; text-align: center; padding: 10px 12px;text-decoration: none;font-size: 20px;} .footer {position:absolute;left:0;bottom: 0;width:100%;background-color:none;color:green;text-align: center;height: 100px;}.active {background-color:gray;color: white;}.topnav .icon {display: none;}.dropdown {float: left;overflow: hidden;}.dropdown .dropbtn {font-size: 17px; border: none;outline: none;color: white;padding: 14px 16px;background-color: inherit;font-family: inherit;margin: 0;}.dropdown-content {display: none;position: absolute;background-color: #f9f9f9;min-width: 160px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);"+
				 "z-index: 1;}.dropdown-content a {float: none;color: black;padding: 12px 16px;text-decoration: none;display: block;text-align: left;}.topnav a:hover, .dropdown:hover .dropbtn {background-color: #555;color: white;}.dropdown-content a:hover {"+
				   "background-color: #ddd;color: black;}.dropdown:hover .dropdown-content {display: block;}@media screen and (max-width: 600px) {.topnav a:not(:first-child), .dropdown .dropbtn {display: none;}.topnav a.icon {float: right;display: block;}}@media screen and (max-width: 600px) {.topnav.responsive {position: relative;}.topnav.responsive a.icon {position: absolute;right: 0;top: 0;}.topnav.responsive a {float: none;display: block;text-align: left;}.topnav.responsive .dropdown {float:none;}.topnav.responsive .dropdown-content {position: relative;}.topnav.responsive .dropdown .dropbtn {display: block;width: 100%;text-align: left;}} h3{ color:black;}"
				   + "img{float:left;}th{background-color:#b3ff99;color:blue;} td{color:black;}h3{color:black}a{color:brown}</style></style></head><body><center><font size='5' color='black'><i><b>ADVANCED SCHOOLING SYSTEM</i></b></font></center><div class='topnav' id='myTopnav'><img src='logo1-2.jpg' class='img-circle' alt='symbol' height='70'></img></a><a href='#home' class='active'>Home</a><a href='#news'>About</a></div><center><h2 color='black'>");
		String file=request.getParameter("click");
		String table=request.getParameter("table");
		HttpSession sess=request.getSession(false);
		sess.setAttribute("sfile",file);
		sess.setAttribute("tab",table);
		String cla=(String)sess.getAttribute("cla");
		if(!(cla!=null)) 
		{
			cla=request.getParameter("classs");
		}
		out.println("<html><body><center>");
		out.println("<h3>Selected Student Details</h3>");
		out.println("<table border='1'>");
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			PreparedStatement ps=con.prepareStatement("select * from "+table+" where scopy=?");
			ps.setString(1,file);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				out.println("<tr><td><b>STUDENT NAME</b></td>");
				out.println("<td>"+rs.getString("sname")+"</td></tr>");
				out.println("<tr><td><b>AADHAR NUMBER</b></td>");
				out.println("<td>"+rs.getString("saadhar")+"</td></tr>");
				sess.setAttribute("aad",rs.getString("saadhar"));
				out.println("<tr><td><b>JOINING CLASS</b></td>");
				out.println("<td>"+cla+"</td></tr>");
				out.println("<tr><td><b>CASTE</b></td>");
				out.println("<td>"+rs.getString("scaste")+"</td></tr>");
				out.println("<tr><td><b>FATHER NAME</b></td>");
				out.println("<td>"+rs.getString("sfname")+"</td></tr>");
				out.println("<tr><td><b>MOBILE</b></td>");
				out.println("<td>"+rs.getString("smob")+"</td></tr>");
				out.println("<tr><td><b>EMAIL</b></td>");
				out.println("<td>"+rs.getString("smail")+"</td></tr>");
				out.println("<tr><td><b>FILE</b></td>");
				out.println("<td><a href='File_download' style='color:brown'>AUTHORIZATION DOCUMENT</a></td></tr>");
				
			}
	}
catch(Exception e)
		{
	System.out.println(e);
		}
		out.println("</table>");
		out.println("<button type='submit'><a href='Actionstud' style='color:green;'>ACCEPT</a></button>");
		out.println("<button type='submit'><a href='Reasonstud' style='color:red;'>DECLINE</a></button><br><br>");
		out.println("</center>");
		out.println("</body></html>");
	}
	}
