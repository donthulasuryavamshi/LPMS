

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Promote
 */
@WebServlet("/Promote")
public class Promote extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Promote() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession sess=request.getSession(false);
		String sid=(String)sess.getAttribute("id");
		String yr=request.getParameter("table");
		String sclass=request.getParameter("sclass");
		String action=request.getParameter("action");

		String pyr=" ",cyr=" ";
		int date=0,kyr=0;
		int yr0=0,yr1=0,c1=0,i=1,d=0;
		out.println("<html><body><center>");
		out.println("<h1><u>Students of This Class</u></h1>");
		out.println("<table border='1'><tr>");
		out.println("<th>S NO</th>");
		out.println("<th>STUDENT AADHAR</th>");
		out.println("<th>STUDENT NAME</th>");
		out.println("<th>ACTION-1</th>");
		out.println("<th>ACTION-2</th></tr>");
		out.println("<form action='Promotedd'>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/verifiedstud","root","");
			PreparedStatement ps=con1.prepareStatement("select * from "+yr+" where saadhar=?");
			ps.setString(1,action);
		   ResultSet rs1= ps.executeQuery();
		   while(rs1.next())
		   {
			   out.println("<tr><td>"+i+++".</td>");
				out.println("<td>"+rs1.getString("saadhar")+"</td>");
				out.println("<td>"+rs1.getString("sname")+"</td>");
				out.println("<input type='hidden' name='table' value='"+yr+"'>");
				out.println("<input type='hidden' name='ssclass' value='"+sclass+"'>");
				out.println("<td><input type='text' name='marks' placeholder='Enter percentage'></td>");
				out.println("<td><button type='submit' style='background-color:#ccff99; color:black;' name='action' value='"+rs1.getString("saadhar")+"'>PROMOTE</button></td></tr>");
		  
		   }
		   con1.close();
		   
			}
		
		catch(Exception e)
		{
			out.println(e);
		}
		out.println("</table><center>");
		String classs=(String)sess.getAttribute("cla");
		out.println("<input type='hidden' name='sclass' value='"+classs+"'>");
		out.println("<br><br><br><button type='submit' formaction='SelectStudentPer' style='background-color:red; color:black;' name='action'>GO BACK</button>");
		   out.println("</form></center></body></html>");

		   
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
