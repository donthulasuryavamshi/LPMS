

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ForgotPassword
 */
@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgotPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	String to=request.getParameter("email");
		String num=UUID.randomUUID().toString().replace("-", "");
		String send=request.getParameter("action");
		int c=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			if(send.equals("admin"))
			{
			PreparedStatement p=con.prepareStatement("select mail from admin");
			ResultSet rs=p.executeQuery();
			while(rs.next())
			{
				if(rs.getString(1).equals(to))
				{
					c=1;
				}
			}
			if(c==0)
			{
				out.println("<html><center> <h4>mail didnt  register for any admin </h4>");
				out.println("<a href='forgotpassworda.html'>Try new email</a><br><br>");
			}
				if(c==1) {
					
					PreparedStatement ps=con.prepareStatement("insert into linkdetails values(?,?)");
					ps.setString(1,to);
					ps.setString(2,num);
					ps.executeUpdate();
					Mail.sendfp(to,num,send);
					out.println("<html><center> <h4>link has been sent successfully<br> Check mail for the link.<br><br><br>");
				}
	}
			if(send.equals("school"))
			{
				PreparedStatement p=con.prepareStatement("select smail from schooldetails");
				ResultSet rs=p.executeQuery();
				while(rs.next())
				{
					if(rs.getString(1).equals(to))
					{
						c=1;
					}
				}
				if(c==0)
				{
					out.println("<html><center> <h4>mail didnt  register for any admin </h4>");
					out.println("<a href='forgotpasswords.html'>Try new email</a><br><br>");
				}
					if(c==1) {
						
						PreparedStatement ps=con.prepareStatement("insert into linkdetails values(?,?)");
						ps.setString(1,to);
						ps.setString(2,num);
						ps.executeUpdate();
						Mail.sendfp(to,num,send);
						out.println("<html><center> <h4>link has been sent successfully<br> Check mail for the link.<br><br><br>");
					}
		}
			}
		
		catch(Exception e) {
			out.println(e);
		}
		
		
	
		out.println("<a href='AdminLogin.html'>BACK</a></center></body></html>");
		
		
}
	

	}


