

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String s1=request.getParameter("id");
		String s2=request.getParameter("pwd");
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		int ec=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select admid,password,ipaddr,ipaddr2,mandal from admin ");
			while(rs.next()) {
				if(rs.getString(1).equals(s1))
				{
					ec=1;
					if(rs.getString(2).equals(s2))
					{
						ec=2;
							HttpSession sess=request.getSession();
						    sess.setAttribute("id",s1);
						    
						    InetAddress inetAddress = InetAddress.getLocalHost();
					        //out.println("Host Name:- " + inetAddress.getHostName());
						    if(s1.equals("tsschladm"))
						    {
						    	if(inetAddress.getHostAddress().equals(rs.getString(3))||inetAddress.getHostAddress().equals(rs.getString(4))) 
						    response.sendRedirect("AdmSuper.html");
						    else { 
						    	out.println("<center><h1>You must login through ur system containing your IP address</h1>");
						    	out.println("<a href='AdminLogin.html'>RETRY LOGIN</a>");
						    }
						   }
						    else if(rs.getString(5)==null)
						    {
						    	response.sendRedirect("DistAdminHome.html");
						    }
						 else {
						    	response.sendRedirect("AdminHome.html");
						    	}
				}
			}
			}
			
					if(ec==1){
						out.println("<center>Password is incorrect<br><br><br>");
						out.println("<a href='AdminLogin.html'>RETRY LOGIN</a>");
					}
				
				if(ec==0){
					out.println("<center>ID entered never exist<br><br><br>");
					out.println("<a href='AdminLogin.html'>RETRY LOGIN</a>");
				}
			
		}
		catch(Exception e) {
				
			}
			
	}


	}

