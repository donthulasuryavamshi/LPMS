

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Alter
 */
@WebServlet("/Alter")
public class Alter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int k=0,yr1=0,c=2,yr7=0,yr8=0,yr9=0,yr10=0;
		String currdate=null;
		String mon="",yr=" ",yr2="class_",yr3=" ",yr0=" ",yer=" ",name=" ";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/verifiedstud","root","");
			Connection con3=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Statement s0=con3.createStatement();
			PreparedStatement ps3=con3.prepareStatement("select year,creation,eyear from academic");
			ResultSet rs3=ps3.executeQuery();
			while(rs3.next())
			{
				yr7=rs3.getInt(1);
				yr8=rs3.getInt(3);
				SimpleDateFormat dateformat= new SimpleDateFormat("YYYY");
				yr9=Integer.parseInt(dateformat.format(rs3.getDate(2)));
			}
				if(yr8-yr9>=10)
				{
					yr9=yr8-10;
				}
				
					String[] co= {" ","first","second","third","fourth","fifth","sixth","seventh","eighth","nineth","tenth"};
					for(int j=1;j<=co.length;j++)
					{
						if(yr9<=yr8-2)
						{
						name=co[++j];
						yr10=yr9+1;
						yr="yr"+yr9+"_"+yr10;
						yr9++;
						PreparedStatement ps=con1.prepareStatement("alter table "+yr+" add (percent int(5), "+name+" varchar(10))");
						ps.executeUpdate();
						}
						else if(yr9==yr8-1)
						{
							PreparedStatement ps=con1.prepareStatement("alter table "+yr+" add (percent int(5))");
							ps.executeUpdate();
							response.sendRedirect("performance.html");
						}
					}
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
