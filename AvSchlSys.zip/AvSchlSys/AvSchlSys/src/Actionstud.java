

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Actionstud
 */
@WebServlet("/Actionstud")
public class Actionstud extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Actionstud() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession sess=request.getSession(false);
		String aad=(String)sess.getAttribute("aad");
		String table=(String)sess.getAttribute("tab");
		int year=(int)sess.getAttribute("year");
		String cla=(String)sess.getAttribute("cla");
		out.println("<html><body><center>");
		int k=0;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/verifiedstud","root","");
			PreparedStatement ps=con1.prepareStatement("select * from "+table+" where saadhar=?");
			ps.setString(1,aad);
			PreparedStatement ps3=con1.prepareStatement("delete from "+table+" where saadhar=?");
			ps3.setString(1,aad);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				PreparedStatement ps1=con2.prepareStatement("insert into "+table+" (saadhar,sname,sfname,scaste,smob,smail,scopy,"+cla+") values(?,?,?,?,?,?,?,?)");
		        ps1.setString(1,rs.getString("saadhar"));
				ps1.setString(2,rs.getString("sname"));
				ps1.setString(3,rs.getString("sfname"));
				ps1.setString(4,rs.getString("scaste"));
				ps1.setString(5,rs.getString("smob"));
				ps1.setString(6,rs.getString("smail"));
				ps1.setString(7,rs.getString("scopy"));
				ps1.setString(8,rs.getString(""+cla+""));
				k=ps1.executeUpdate();
				//out.println("1");
				ps3.executeUpdate();
				sess.removeAttribute("sfile");
				}
			
			if(k==0)
			{
				out.println("<h2>Error insertion.Try Again</h2><br><br>");
				out.println("<a href='Verify' method='post'>Try Again</a>");
			}
			else
			{
				out.println("<h2>Successfully accepted and inserted</h2><br><br>");
				if(year==0)
				out.println("<a href='SelectStudent'>VERIFY MORE</a>");
				else
					out.println("<a href='verifyclass1.html'>VERIFY MORE</a>");
		}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
