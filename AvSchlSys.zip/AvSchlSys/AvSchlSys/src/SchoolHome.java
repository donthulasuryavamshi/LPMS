

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SchoolHome
 */
@WebServlet("/SchoolHome")
public class SchoolHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SchoolHome() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd1=request.getRequestDispatcher("slogin.html");
		rd1.include(request, response);
		int ch=0;
		HttpSession sess=request.getSession(false);
	    String id=(String)sess.getAttribute("id");
	    ch=1;
		String currdate=null;
		String mon="";
		int yr=0,date=0,yr1=0,yr2=0,a=0;		
		out.println("<html><style>h1,h2,h3,h5{color:black;}a{color:blue;}</style><body><center>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			PreparedStatement stmt=con.prepareStatement("select year,creation from schooldetails where sid=?");
			stmt.setString(1,id);
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				  DateFormat dateFormat = new SimpleDateFormat("yyyy");
				date=Integer.parseInt(dateFormat.format(rs.getDate(2)));
				a=rs.getInt(1);
			}
				PreparedStatement ps4=con.prepareStatement("select CURRENT_DATE");
				ResultSet rs4=ps4.executeQuery();
				while(rs4.next())
				{
					currdate=rs4.getString(1);
					mon=currdate.substring(5,7);//0000-00-00
					yr=Integer.parseInt(currdate.substring(0,4));
				}
				PreparedStatement ps3=con.prepareStatement("select year from academic");
				ResultSet rs3=ps3.executeQuery();
				while(rs3.next())
				{
					yr1=rs3.getInt(1);
				}
				if(yr-date!=a)
				{
					yr2=yr-date;
					PreparedStatement stmt4=con.prepareStatement("update schooldetails set year='"+yr2+"' where sid=?");
					stmt4.setString(1,id);
					stmt4.executeUpdate();
				}
				yr2=yr-date;
				if((mon.equals("06")||mon.equals("07"))&&yr1==yr&&yr2!=0)
				{
					out.println("<h3>School Registered from &nbsp;"+(yr2)+"&nbsp; years</h3>");
					
					out.println("<h2><a href='add.html'>Add Students</a></h2>");
					}
				else if(yr1+1==yr)
				{
					out.println("<h1>You cant add Student now.<br><br> This Academic Year is not enabled yet.<br>WAIT for it<br>");
				}
				else if(a==0)
				{
				out.println("<h3>NEWLY REGISTERED SCHOOL </h3>");
				if(mon.equals("06")||mon.equals("07"))
				{
					out.println("<h2><a href='FileSUpload.html'>Add Students</a></h2>");
				}
				else {
					out.println("<h1>You cant add Student now.<br><br> If u really want to add student, write Request Regarding Student Issue in Complaint Tab");
					out.println("<h5>Complaint tab can be seen in navigation bar(UP)</h5>");
				}
				}
	
		}
		catch(Exception e)
		{
			out.println(e);
		}
		finally {
			if(ch!=1)
				out.println("<br><br><br><br><h3 style='color:red'>Error.RELOGIN PLZZZ<h3>");
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
