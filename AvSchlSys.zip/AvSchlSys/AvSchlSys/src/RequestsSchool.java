

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.sql.Connection;  
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RequestsSchool
 */
@WebServlet("/RequestsSchool")
public class RequestsSchool extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RequestsSchool() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html> <head> <link rel='stylesheet' type='text/css' href='index.css'> <meta charset='ISO-8859-1'> <style><link rel='stylesheet' type='text/css' href='index.css'<style>body{background-color:#f2f2f2;border-left: 15px solid gray;border-right: 15px solid gray;border-top: 15px solid gray;border-radius:30px;}.topnav {background-color: #333;overflow: hidden;width:99%;}.topnav a {float: left;display: block;"+
				" color: #f1f1f1; text-align: center; padding: 10px 12px;text-decoration: none;font-size: 20px;} .footer {position:absolute;left:0;bottom: 0;width:100%;background-color:none;color:green;text-align: center;height: 100px;}.active {background-color:gray;color: white;}.topnav .icon {display: none;}.dropdown {float: left;overflow: hidden;}.dropdown .dropbtn {font-size: 17px; border: none;outline: none;color: white;padding: 14px 16px;background-color: inherit;font-family: inherit;margin: 0;}.dropdown-content {display: none;position: absolute;background-color: #f9f9f9;min-width: 160px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);"+
				 "z-index: 1;}.dropdown-content a {float: none;color: black;padding: 12px 16px;text-decoration: none;display: block;text-align: left;}.topnav a:hover, .dropdown:hover .dropbtn {background-color: #555;color: white;}.dropdown-content a:hover {"+
				   "background-color: #ddd;color: black;}.dropdown:hover .dropdown-content {display: block;}@media screen and (max-width: 600px) {.topnav a:not(:first-child), .dropdown .dropbtn {display: none;}.topnav a.icon {float: right;display: block;}}@media screen and (max-width: 600px) {.topnav.responsive {position: relative;}.topnav.responsive a.icon {position: absolute;right: 0;top: 0;}.topnav.responsive a {float: none;display: block;text-align: left;}.topnav.responsive .dropdown {float:none;}.topnav.responsive .dropdown-content {position: relative;}.topnav.responsive .dropdown .dropbtn {display: block;width: 100%;text-align: left;}} h3{ color:black;}"
				   + "img{float:left;}"
				   + "th{background-color:#b3ff99;color:blue;} td{color:black;}</style></head><body><center><font size='5' color='black'><i><b>ADVANCED SCHOOLING SYSTEM</i></b></font></center><div class='topnav' id='myTopnav'><img src='logo1-2.jpg' class='img-circle' alt='symbol' height='70'></img></a><a href='#home' class='active'>Home</a><a href='#news'>About</a></div><center><h2 color='black'>");
		HttpSession sess=request.getSession(false);
		String id=(String)sess.getAttribute("id");
		int i=1;
		out.println("<html><body><center>");
		out.println("<h1><u>Requests For Registration of Schools</u></h1>");
		out.println("<table border='1'><tr>");
		out.println("<th>S NO</th>");
		out.println("<th>SCHOOL NAME</th>");
		out.println("<th>SCHOOL TYPE</th>");
		out.println("<th>MANDAL</th>");
		out.println("<th>VIEW</th></tr>");
		out.println("<form action='RequestsOpen'>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select admid,district,mandal from admin ");
			while(rs.next()) {
				if(rs.getString(1).equals(id))
				{
					if(rs.getString(3)==null) {
						Statement stmt1=con.createStatement();
						ResultSet rs1=stmt1.executeQuery("select sname,sdist,stype,sfile from unschooletails ");
						while(rs1.next())
						{
							if(rs1.getString(2).equals(rs.getString(2)))
							{
							out.println("<tr><td>"+i+++".</td>");
							out.println("<td>"+rs1.getString(1)+"</td>");
							out.println("<td>"+rs1.getString(3)+"</td>");
							out.println("<td>"+rs1.getString(2)+"</td>");
							out.println("<td><button type='submit' style='color:blue;' name='view' value='"+rs1.getString(4)+"'>DETAILS</button></td></tr>");
							}
							}
							
						
					}
				}
						
				}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		out.println("</form></table></center></body>"); 
		   out.println("</html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated 
	}
	
}
