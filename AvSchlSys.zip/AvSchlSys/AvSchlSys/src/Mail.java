

import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Mail
 */
@WebServlet("/Mail")
public class Mail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Mail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public static void send(String to,String subject,String id,String pwd){

		final String user="mockeducation@gmail.com";//change accordingly
		final String passw="mock100eu";
		final String sid=id;
		final String spwd=pwd;

	//1st step) Get the session object	
	Properties props = new Properties();
	props.put("mail.smtp.host", "smtp.gmail.com");//change accordingly
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.starttls.enable", "true");
	props.put("mail.smtp.port", "587");

	  Session session = Session.getDefaultInstance(props,  
			    new javax.mail.Authenticator() {  
			      protected PasswordAuthentication getPasswordAuthentication() {  
			    return new PasswordAuthentication(user,passw);  
			      }  
			    });  
	//2nd step)compose message
	try {
		String body="Mail";
	 MimeBodyPart mbp=new MimeBodyPart();
	 mbp.setContent(body,"text/html");
	 MimeMultipart multipart = new MimeMultipart();
	 multipart.addBodyPart(mbp);
		MimeMessage message = new MimeMessage(session);
	 message.setFrom(new InternetAddress(user));
	 message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
	 message.setSubject(subject);
	 message.setContent("<html><br>" + 
			 				"<body><br>" + 
			 					"<br>" + 
			 				"<br>MOCK EDUCATION BOARD" +
			 				"<br><br>Registration is successfull <br> Your Details are below" +
			 					"<br> SCHOOL ID:"+sid+
			 					" <br><br> PASSWORD:"+spwd+
			 					"<br><br>" +
			 					"<br><a href='http://localhost:8088/AvSchlSys/slogin.html'>School Login Page</a>"+
			 					"<br><br>" +
			 					"</body></html>", "text/html");
	 //3rd step)send message
	 Transport.send(message);

	 System.out.println("Done");

	 } catch (MessagingException mex) {mex.printStackTrace();}  
		
		
	}
	public static void sendd(String to,String subject,String id,String pwd){

		final String user="mockeducation@gmail.com";//change accordingly
		final String passw="mock100eu";
	//1st step) Get the session object	
	Properties props = new Properties();
	props.put("mail.smtp.host", "smtp.gmail.com");//change accordingly
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.starttls.enable", "true");
	props.put("mail.smtp.port", "587");

	  Session session = Session.getDefaultInstance(props,  
			    new javax.mail.Authenticator() {  
			      protected PasswordAuthentication getPasswordAuthentication() {  
			    return new PasswordAuthentication(user,passw);  
			      }  
			    });  
	//2nd step)compose message
	try {
		String body="Mail";
	 MimeBodyPart mbp=new MimeBodyPart();
	 mbp.setContent(body,"text/html");
	 MimeMultipart multipart = new MimeMultipart();
	 multipart.addBodyPart(mbp);
		MimeMessage message = new MimeMessage(session);
	 message.setFrom(new InternetAddress(user));
	 message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
	 message.setSubject(subject);
	 message.setContent("<html><br>" + 
			 				"<body><br>" + 
			 					"<br>" + 
			 				"<br>MOCK EDUCATION BOARD" +
			 				"<br><br>Registration is successfull <br> Your Details are below" +
			 					"<br> ADMIN ID:"+id+
			 					" <br><br> PASSWORD:"+pwd+
			 					"<br><br>" +
			 					"<br><a href='http://localhost:8088/AvSchlSys/AdminLogin.html'>School Login Page</a>"+
			 					"<br><br>" +
			 					"</body></html>", "text/html");
	 //3rd step)send message
	 Transport.send(message);

	 System.out.println("Done");

	 } catch (MessagingException mex) {mex.printStackTrace();}  
	}
	
	public static void sendm(String to,String subject,String id,String pwd){

		final String user="mockeducation@gmail.com";//change accordingly
		final String passw="mock100eu";
		

	//1st step) Get the session object	
	Properties props = new Properties();
	props.put("mail.smtp.host", "smtp.gmail.com");//change accordingly
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.starttls.enable", "true");
	props.put("mail.smtp.port", "587");

	  Session session = Session.getDefaultInstance(props,  
			    new javax.mail.Authenticator() {  
			      protected PasswordAuthentication getPasswordAuthentication() {  
			    return new PasswordAuthentication(user,passw);  
			      }  
			    });  
	//2nd step)compose message
	try {
		String body="Mail";
	 MimeBodyPart mbp=new MimeBodyPart();
	 mbp.setContent(body,"text/html");
	 MimeMultipart multipart = new MimeMultipart();
	 multipart.addBodyPart(mbp);
		MimeMessage message = new MimeMessage(session);
	 message.setFrom(new InternetAddress(user));
	 message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
	 message.setSubject(subject);
	 message.setContent("<html><br>" + 
			 				"<body><br>" + 
			 					"<br>" + 
			 				"<br>MOCK EDUCATION BOARD" +
			 				"<br><br>Registration is successfull <br> Your Details are below" +
			 					"<br> ADMIN ID:"+id+
			 					" <br><br> PASSWORD:"+pwd+
			 					"<br><br>" +
			 					"<br><a href='http://localhost:8088/AvSchlSys/AdminLogin.html'>Admin Login Page</a>"+
			 					"<br><br>" +
			 					"</body></html>", "text/html");
	 //3rd step)send message
	 Transport.send(message);

	 System.out.println("Done");

	 } catch (MessagingException mex) {mex.printStackTrace();}  
		
		
	}
	public static void send(String to,String subject,String reason){

		final String user="mockeducation@gmail.com";//change accordingly
		final String passw="mock100eu";
		

	//1st step) Get the session object	
	Properties props = new Properties();
	props.put("mail.smtp.host", "smtp.gmail.com");//change accordingly
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.starttls.enable", "true");
	props.put("mail.smtp.port", "587");

	  Session session = Session.getDefaultInstance(props,  
			    new javax.mail.Authenticator() {  
			      protected PasswordAuthentication getPasswordAuthentication() {  
			    return new PasswordAuthentication(user,passw);  
			      }  
			    });  
	//2nd step)compose message
	try {
		String body="Mail";
	 MimeBodyPart mbp=new MimeBodyPart();
	 mbp.setContent(body,"text/html");
	 MimeMultipart multipart = new MimeMultipart();
	 multipart.addBodyPart(mbp);
		MimeMessage message = new MimeMessage(session);
	 message.setFrom(new InternetAddress(user));
	 message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
	 message.setSubject(subject);
	 message.setContent("<html><br>" + 
			 				"<body><br>" + 
			 					"<br>" + 
			 				"<br>MOCK EDUCATION BOARD" +
			 				"<br><br>Registration is Unsuccessfull <br> Your Details are below" +
			 					"<br><br>" +
			 					"<br><a href='http://localhost:8088/AvSchlSys/slogin.html'>School Login Page</a>"+
			 					"<br><br>" +
			 					"Reason is"+reason+"<br><br>"+
			 					"</body></html>", "text/html");
	 //3rd step)send message
	 Transport.send(message);

	 System.out.println("Done");

	 } catch (MessagingException mex) {mex.printStackTrace();}  
		
		
	}
	public static void sendfp(String to,String num,String action){

		final String user="mockeducation@gmail.com";//change accordingly
		final String passw="mock100eu";
		

	//1st step) Get the session object	
	Properties props = new Properties();
	props.put("mail.smtp.host", "smtp.gmail.com");//change accordingly
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.starttls.enable", "true");
	props.put("mail.smtp.port", "587");

	  Session session = Session.getDefaultInstance(props,  
			    new javax.mail.Authenticator() {  
			      protected PasswordAuthentication getPasswordAuthentication() {  
			    return new PasswordAuthentication(user,passw);  
			      }  
			    });  
	//2nd step)compose message
	try {
		String body="Mail";
	 MimeBodyPart mbp=new MimeBodyPart();
	 mbp.setContent(body,"text/html");
	 MimeMultipart multipart = new MimeMultipart();
	 multipart.addBodyPart(mbp);
		MimeMessage message = new MimeMessage(session);
	 message.setFrom(new InternetAddress(user));
	 message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
	 message.setSubject("Forgot Password mail");
	 message.setContent("<html><br>" + 
			 				"<body><br>" + 
			 					"<br>" + 
			 				"<br>MOCK EDUCATION BOARD" +
			 				"<br><br>Forgot password link <br> Your Details are below" +
			 					"<br><br>" +
			 				
			 					"<br>http://localhost:8088/AvSchlSys/Storef?uuid="+ num +">" +
			 					"<br><br>" +
			 					"</body></html>", "text/html");
	 //3rd step)send message
	 Transport.send(message);

	 System.out.println("Done");

	 } catch (MessagingException mex) {mex.printStackTrace();}  
		
		
	}



}


