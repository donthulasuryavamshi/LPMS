

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class File_download
 */
@WebServlet("/File_download")
public class File_download extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public File_download() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		HttpSession s=request.getSession(false);
		String sfile=(String)s.getAttribute("sfile");
		File download =new File(sfile);
		FileInputStream fileInputStream = new FileInputStream(download);
		String relativePath=getServletContext().getRealPath("");
		System.out.println(relativePath);
		ServletContext context=getServletContext();
		String mimetype=context.getMimeType(sfile);
		if(mimetype==null)
		{
			mimetype="APPLICATION/OCTET-STREAM";
		}
		System.out.println(mimetype);
		response.setContentType(mimetype);
		//response.setContentType("APPLICATION/OCTET-STREAM");
		response.setContentLength((int)download.length());
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ download.getName() + "\"");
		OutputStream output=response.getOutputStream();
		byte[] buffer=new byte[4096];
		int bytesRead=-1;
		while((bytesRead=fileInputStream.read(buffer))!=-1)
		{
			output.write(buffer,0,bytesRead);
		}
		fileInputStream.close();
		output.close();
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
