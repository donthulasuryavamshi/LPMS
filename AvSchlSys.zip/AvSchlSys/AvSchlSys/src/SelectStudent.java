

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SelectStudent
 */
@WebServlet("/SelectStudent")
public class SelectStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html> <head> <link rel='stylesheet' type='text/css' href='index.css'> <meta charset='ISO-8859-1'> <style><link rel='stylesheet' type='text/css' href='index.css'<style>body{background-color:#f2f2f2;border-left: 15px solid gray;border-right: 15px solid gray;border-top: 15px solid gray;border-radius:30px;}.topnav {background-color: #333;overflow: hidden;width:99%;}.topnav a {float: left;display: block;"+
				" color: #f1f1f1; text-align: center; padding: 10px 12px;text-decoration: none;font-size: 20px;} .footer {position:absolute;left:0;bottom: 0;width:100%;background-color:none;color:green;text-align: center;height: 100px;}.active {background-color:gray;color: white;}.topnav .icon {display: none;}.dropdown {float: left;overflow: hidden;}.dropdown .dropbtn {font-size: 17px; border: none;outline: none;color: white;padding: 14px 16px;background-color: inherit;font-family: inherit;margin: 0;}.dropdown-content {display: none;position: absolute;background-color: #f9f9f9;min-width: 160px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);"+
				 "z-index: 1;}.dropdown-content a {float: none;color: black;padding: 12px 16px;text-decoration: none;display: block;text-align: left;}.topnav a:hover, .dropdown:hover .dropbtn {background-color: #555;color: white;}.dropdown-content a:hover {"+
				   "background-color: #ddd;color: black;}.dropdown:hover .dropdown-content {display: block;}@media screen and (max-width: 600px) {.topnav a:not(:first-child), .dropdown .dropbtn {display: none;}.topnav a.icon {float: right;display: block;}}@media screen and (max-width: 600px) {.topnav.responsive {position: relative;}.topnav.responsive a.icon {position: absolute;right: 0;top: 0;}.topnav.responsive a {float: none;display: block;text-align: left;}.topnav.responsive .dropdown {float:none;}.topnav.responsive .dropdown-content {position: relative;}.topnav.responsive .dropdown .dropbtn {display: block;width: 100%;text-align: left;}} h3{ color:black;}"
				   + "img{float:left;}th{background-color:#b3ff99;color:blue;} td{color:black;}h3{color:black}</style></style></head><body><center><font size='5' color='black'><i><b>ADVANCED SCHOOLING SYSTEM</i></b></font></center><div class='topnav' id='myTopnav'><img src='logo1-2.jpg' class='img-circle' alt='symbol' height='70'></img></a><a href='#home' class='active'>Home</a><a href='#news'>About</a></div><center><h2 color='black'>");
		HttpSession sess=request.getSession(false);
		String sid=(String)sess.getAttribute("sid");
		String classs=request.getParameter("sclass");
		sess.setAttribute("cla",classs);
		String pyr=" ",cyr=" ";
		String yr=" ";
		String di="";
		int yr0=0,yr1=0,c1=0,i=1,d=0;
		out.println("<html><body><center>");
		out.println("<h3><u>Students of This Class</u></h3>");
		out.println("<table border='1'><tr>");
		out.println("<th>S NO</th>");
		out.println("<th>Student AADHAR</th>");
		out.println("<th>STUDENT NAME</th>");
		out.println("<th>VIEW</th></tr>");
		out.println("<form action='Verify' method='post'>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con0=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/unverifiedstud","root","");
			Statement s0=con0.createStatement();
			PreparedStatement stmt0=con0.prepareStatement("select sdist from schooldetails where sid=?");
			stmt0.setString(1,sid);
			ResultSet rs10=stmt0.executeQuery();
			while(rs10.next()) {
				di=rs10.getString(1);
			}
			System.out.println(di);
			ResultSet rs0=s0.executeQuery("select * from academic");
			while(rs0.next())
			{
				pyr=rs0.getString(2).substring(0,4);
				cyr=rs0.getString(1);
			}
				yr0=Integer.parseInt(pyr);
				yr1=Integer.parseInt(cyr);
				for(int c=yr0;c<=yr1;c++)
				{
					c1=c+1;
					yr="_"+c+"_"+c1;
			PreparedStatement ps=con1.prepareStatement("select * from "+di+yr+" where "+classs+"=?");
			ps.setString(1,sid);
		   ResultSet rs1= ps.executeQuery();
		   while(rs1.next())
		   {
			   out.println("<tr><td>"+i+++".</td>");
				out.println("<td>"+rs1.getString("saadhar")+"</td>");
				out.println("<td>"+rs1.getString("sname")+"</td>");
				out.println("<input type='hidden' name='table' value='"+di+yr+"'>");
				out.println("<td><button type='submit' style='background-color:'orange' 'color:black;' name='click' value='"+rs1.getString("scopy")+"'>CLICK</button></td></tr>");
			}
		   }
			}
		catch(Exception e)
		{
			System.out.println(e);
		}
		out.println("</form></table><center>");
		out.println("<br><br><br><button type='submit'><a href='verifyclasses.html' style='color:red;'>GO BACK</a></button>");
		   out.println("</center></body></html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

			}
	



