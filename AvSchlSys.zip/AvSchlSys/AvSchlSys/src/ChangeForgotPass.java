

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ChangeForgotPass
 */
@WebServlet("/ChangeForgotPass")
public class ChangeForgotPass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeForgotPass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession(false);
		String uuid=(String)session.getAttribute("uuidf");
		String newp=request.getParameter("new");
	    String confirm=request.getParameter("confirm");
	    String mail="";
	    out.println("<html><body><center><h2>");
	    int k=0,r1=0,r2=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/advschlsys","root","");
			PreparedStatement stmt2=con.prepareStatement("select email from linkdetails where uuid=?");
			stmt2.setString(1,uuid);
			ResultSet rs2=stmt2.executeQuery();
			while(rs2.next())
			{
				mail=rs2.getString(1);
			}
			if(newp.equals(confirm))
			{
			PreparedStatement stmt1=con.prepareStatement("update schooldetails  set spwd=? where smail=?");
			stmt1.setString(1,newp);
			stmt1.setString(2,mail);
			r1=stmt1.executeUpdate();
			}
			else
			{
				k=-1;
			}
			if(newp.equals(confirm))
			{
			PreparedStatement stmt=con.prepareStatement("update admin  set password=? where mail=?");
			stmt.setString(1,newp);
			stmt.setString(2,mail);
			r2=stmt.executeUpdate();
			}
			else
			{
				k=-2;
			}
			if(r1!=0)
			{
				out.println("Password changed successfully<br><br>");
				out.println("<a href='schoollogin.html'>LOGIN VERIFY</a>");	
			}
			if(r2!=0)
			{
				out.println("Password changed successfully<br><br>");
				
				out.println("<a href='AdminLogin.html'>LOGIN VERIFY</a>");	
			}
			if(k==-1||k==-2)
			{
				out.println("New Password and Confirm Password didnt match<br><br>");
			}
			if(r1==0&&r2==0)
			{
				out.println("Password didnt change.May Be Invalid Details");
			}
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
	    
	}

		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
}
}