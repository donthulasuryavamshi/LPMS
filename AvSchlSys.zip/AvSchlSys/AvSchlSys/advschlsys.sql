-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2019 at 05:52 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `advschlsys`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic`
--

CREATE TABLE IF NOT EXISTS `academic` (
  `year` int(10) NOT NULL,
  `date` varchar(20) NOT NULL,
  `eyear` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic`
--

INSERT INTO `academic` (`year`, `date`, `eyear`) VALUES
(2019, '2018-07-07', 2019);

-- --------------------------------------------------------

--
-- Table structure for table `adilabad`
--

CREATE TABLE IF NOT EXISTS `adilabad` (
  `mandals` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adilabad`
--

INSERT INTO `adilabad` (`mandals`) VALUES
('Adilabad_urban'),
('Adilabad_rural'),
('Gudiguda '),
('Utnoor'),
('Bajahatnoor '),
('Mavala'),
('Gudihatnoor'),
('Bela'),
('Boadh'),
('Jainath'),
('Indervelly '),
('Narnoor');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admid` varchar(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `mandal` varchar(80) DEFAULT NULL,
  `mail` varchar(100) NOT NULL,
  `ipaddr` varchar(30) NOT NULL,
  `ipaddr2` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admid`, `password`, `district`, `mandal`, `mail`, `ipaddr`, `ipaddr2`) VALUES
('adladm', 'suryad', 'Adilabad', NULL, 'suryavamshidonthula@gmail.com', '192.168.0.7', '127.0.0.1'),
('afdadm', 'P98WPVG5NJO', 'Kumarambheem_Asifabad', NULL, 'nirmal@gmail.com', '192.168.0.7', '127.0.0.1'),
('hydadm', '7BVQCS8GIAV', 'Hyderabad', NULL, 'hyderabadadmin@gmail.com', '192.168.0.7', '127.0.0.1'),
('jag1jglad1', 'AY3OZJ06AAV', 'Jagtial', 'Jagitial', 'jagtialmandadm1@gmail.com', '192.168.0.7', '127.0.0.1'),
('jag1jglad2', 'jgl', 'Jagtial', 'Jagitial', 'jagtialmandadm2@gmail.com', '192.168.0.7', '127.0.0.1'),
('jag3jglad1', 'rural', 'Jagtial', 'Jagitial_Rural', 'jagitialrural1@gmail.com', '192.168.0.7', '127.0.0.1'),
('jag3jglad2', 'LQG3XTAOZGW', 'Jagtial', 'Jagitial_Rural', 'jagitialrural2@gmail.com', '192.168.0.7', '127.0.0.1'),
('jgladm', 'msr', 'Jagtial', NULL, 'chintusept19@gmail.com', '192.168.0.7', '127.0.0.1'),
('kmradm', '28QZE6HTT67', 'Karimnagar', NULL, 'karimj@gmail.com', '192.168.0.7', '127.0.0.1'),
('mdcadm', 'medchal', 'Medchal_Malkajgiri', NULL, 'Medchaladmin@gmail.com', '192.168.0.7', '127.0.0.1'),
('nkladm', '9GA8FZ6F57E', 'Nagarkurnool', NULL, 'nagar@gmail.com', '192.168.1.22', '127.0.0.1'),
('nmladm', 'HOX10NVJYRI', 'Nirmal', NULL, 'nirmal@gmail.com', '192.168.0.7', '127.0.0.1'),
('san1srdad1', 'srd', 'Sangareddy', 'Sangareddy', 'chintusept19@gmail.com', '192.168.0.7', '127.0.0.1'),
('san1srdad2', 'V54WMWWLXQ6', 'Sangareddy', 'Sangareddy', 'chintusept19@gmail.com', '192.168.0.7', '127.0.0.1'),
('srcadm', 'F9KLQUEM5EU', 'Rajanna_Sircilla', NULL, 'karimj@gmail.com', '192.168.0.7', '127.0.0.1'),
('srdadm', 'password', 'Sangareddy', NULL, 'sangareddyadmin@gmail.com', '192.168.0.6', '127.0.0.1'),
('tsschladm', 'password', 'state', 'superadmin', 'tssuperadmin@gmail.com', '192.168.0.6', '127.0.0.1'),
('wguadm', 'YKZLONT5DQP', 'Warangal_Urban', NULL, 'mhs@mm.com', '192.168.0.5', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `bhadradri_kothagudem`
--

CREATE TABLE IF NOT EXISTS `bhadradri_kothagudem` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bhadradri_kothagudem`
--

INSERT INTO `bhadradri_kothagudem` (`mandals`) VALUES
('Manuguru'),
('Karakagudem'),
('Kothagudem'),
('Palwancha'),
('Tekulapalli'),
('Yellandu'),
('Chandrugonda'),
('Aswaraopeta'),
('Mulakalapalli'),
('Dammapeta'),
('Gundala'),
('Julurpadu'),
('Sujathanagar'),
('Chunchupalle'),
('Laxmidevipalli'),
('Allapalli'),
('Annapureddypalli'),
('Bhadrachalam'),
('Dummugudem'),
('Cherla'),
('Burgampahad'),
('Aswapuram'),
('Pinapaka');

-- --------------------------------------------------------

--
-- Table structure for table `hyderabad`
--

CREATE TABLE IF NOT EXISTS `hyderabad` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hyderabad`
--

INSERT INTO `hyderabad` (`mandals`) VALUES
('Shaikpet'),
('Trimulgherry'),
('Bahadurpura'),
('Asifabad'),
('Bandlaguda'),
('Charminar'),
('Golkonda'),
('Himayathnagar'),
(' Nampally'),
('Saidabad'),
('Amberpet'),
('Ameerpet'),
('Khairtabad'),
('Marredpally'),
('Musheerabad'),
('Secunderabad');

-- --------------------------------------------------------

--
-- Table structure for table `jagtial`
--

CREATE TABLE IF NOT EXISTS `jagtial` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jagtial`
--

INSERT INTO `jagtial` (`mandals`) VALUES
('Jagitial'),
('Kathlapur'),
('Jagitial_Rural'),
('Raikal'),
('Sarangapur'),
('Beerpur'),
('Dharmapuri'),
('Buggaram'),
('Pegadapalli'),
('Gollapalli'),
('Mallial'),
('Kodimial'),
('Velgatur'),
('Korutla'),
('Metpalli'),
('Mallapur'),
(' Ibrahimpatnam'),
('Medipalli');

-- --------------------------------------------------------

--
-- Table structure for table `jangaon`
--

CREATE TABLE IF NOT EXISTS `jangaon` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jangaon`
--

INSERT INTO `jangaon` (`mandals`) VALUES
('Jangaon'),
('Bachannapeta'),
('Devaruppala'),
('Gundala'),
('Lingalaghanpur'),
('Narmetta'),
('Raghunathapalle'),
('Tarigoppula'),
('Chilpur'),
('Zaffergadh'),
('Kodakandla'),
('Palakurthi'),
('StationGhanpur');

-- --------------------------------------------------------

--
-- Table structure for table `jayashankar_bhupalapally`
--

CREATE TABLE IF NOT EXISTS `jayashankar_bhupalapally` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jayashankar_bhupalapally`
--

INSERT INTO `jayashankar_bhupalapally` (`mandals`) VALUES
('Bhupalpalle'),
('Kannaigudem'),
('Chityal'),
('Ghanpur'),
('Kataram'),
('Mahadevpur'),
('Maha_Mutharam'),
('Malharrao'),
('Mogullapalle'),
('Palimela'),
('Regonda'),
('Tekumatla'),
('Eturunagaram'),
('Govindaraopet'),
('Mangapet'),
('Mulug'),
('Tadvai'),
('Vajedu'),
('Venkatapur');

-- --------------------------------------------------------

--
-- Table structure for table `jogulamba_gadwal`
--

CREATE TABLE IF NOT EXISTS `jogulamba_gadwal` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jogulamba_gadwal`
--

INSERT INTO `jogulamba_gadwal` (`mandals`) VALUES
('waddepally'),
('Gadwal'),
('Maldakal'),
('Dharur'),
('Ghattu'),
('kaloor_thimmana_Doddi'),
('Ieeja'),
('Alampur'),
('undavelli'),
('Rajoli'),
('Itikyal'),
('Manopad');

-- --------------------------------------------------------

--
-- Table structure for table `kamareddy`
--

CREATE TABLE IF NOT EXISTS `kamareddy` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kamareddy`
--

INSERT INTO `kamareddy` (`mandals`) VALUES
('Banswada'),
('Pitlam'),
('Nizamsagar'),
('Madnoor'),
('Jukkal'),
('Bichkunda	'),
('Birkoor	'),
('Ramareddy'),
('Machareddy	'),
('Domakonda	'),
('Kamareddy	'),
('Rajampet	'),
('Bhiknoor'),
('Nagareddipet'),
('Yellareddy	'),
('Sadasivanagar	'),
('Lingampet	'),
('Gandhari	'),
('Tadwai');

-- --------------------------------------------------------

--
-- Table structure for table `karimnagar`
--

CREATE TABLE IF NOT EXISTS `karimnagar` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karimnagar`
--

INSERT INTO `karimnagar` (`mandals`) VALUES
('Shankarapatnam'),
('Karimnagar'),
('Kothapally'),
('Karimnagar_Rural'),
('Manakondur'),
('Thimmapur'),
('Ganneruvaram'),
('Gangadhara'),
('Ramadugu'),
('Choppadandi'),
('Chigurumamidi'),
('Huzurabad'),
('Veenavanka'),
('V.Saidapur'),
('Jammikunta'),
('Ellandakunta');

-- --------------------------------------------------------

--
-- Table structure for table `khammam`
--

CREATE TABLE IF NOT EXISTS `khammam` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `khammam`
--

INSERT INTO `khammam` (`mandals`) VALUES
('Khammam_Urban'),
('Khammam_Rural	'),
('Tirumalayapalem'),
('Kusumanchi	'),
('Nelakondapalli	'),
('Bonakal	'),
('Chintakani	'),
('Mudigonda	'),
('Konijerla	'),
('Singareni	'),
('Kamepally	'),
('Madhira	'),
('Yerrupalem'),
('Wyra	'),
('Raghunadhapalem'),
('Sattupally	'),
('Vemsoor	'),
('Penuballi	'),
('Kalluru	'),
('Thallada	'),
('Enkoor	');

-- --------------------------------------------------------

--
-- Table structure for table `kumarambheem_asifabad`
--

CREATE TABLE IF NOT EXISTS `kumarambheem_asifabad` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kumarambheem_asifabad`
--

INSERT INTO `kumarambheem_asifabad` (`mandals`) VALUES
('Sirpur_Urban'),
('Bejjur'),
('Lingapur	'),
('Penchicalpet'),
('Jainoor	'),
('Kagaznagar'),
('Tiryani	'),
('Koutala'),
('Asifabad	'),
('Chintalamanepally'),
('Kerameri	'),
('Dahegoan'),
('Wankidi	'),
('Sirpur_Tribal'),
('Rebbena	');

-- --------------------------------------------------------

--
-- Table structure for table `linkdetails`
--

CREATE TABLE IF NOT EXISTS `linkdetails` (
  `email` varchar(50) NOT NULL,
  `uuid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `linkdetails`
--

INSERT INTO `linkdetails` (`email`, `uuid`) VALUES
('shravyashravsjune2@gmail.com', '0006d46f2c59439782d7aec27f9a146f'),
('chintusept19@gmail.com', '092547e12b944282be6c144ee1ad596f'),
('chintusept19@gmail.com', '13085d45e6dd4029aff8d601ec43ca2d'),
('chintusept19@gmail.com', '250e5c8743e9474b97a48312aba980dd'),
('chintusept19@gmail.com', '5b2b1007d45f4880be533f2cb7e11513'),
('suryavamshidonthula@gmail.com', '6a98df145ca14c77b1b76d17bb4e852f'),
('chintusept19@gmail.com', '6bd2fe2f2f5e400caf293ca1732ea21c'),
('chintusept19@gmail.com', 'a3d8304bd7bd4c5dbc2015c5a14d3cc3'),
('suryavamshidonthula@gmail.com', 'e53d8f63f9684508873b73d1118c856e');

-- --------------------------------------------------------

--
-- Table structure for table `linkstudent`
--

CREATE TABLE IF NOT EXISTS `linkstudent` (
  `aadhar` varchar(12) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `linkstudent`
--

INSERT INTO `linkstudent` (`aadhar`, `name`, `sid`) VALUES
('124345678998', 'qaxykbjl', 'srd1SCHS'),
('521345678912', 'VAMSHI VANAM', 'jgl3MCHS'),
('541234567891', 'uftqjkhbj', 'srd1khs'),
('541234567892', 'uftqjkhbj', 'srd1khs'),
('654321789087', 'abcd', 'srd1khs'),
('660512345678', 'MARRIPELLI SRINIVAS RAO', 'jgl3MCHS'),
('987654321098', 'bhanu', 'srd1khs'),
('987654321234', 'akhil srivatsav', 'srd1SCHS');

-- --------------------------------------------------------

--
-- Table structure for table `mahabubabad`
--

CREATE TABLE IF NOT EXISTS `mahabubabad` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahabubabad`
--

INSERT INTO `mahabubabad` (`mandals`) VALUES
('Narsimhulapet'),
('Maripeda	'),
('Nellikudur	'),
('Peddavangara'),
('Thorrur	'),
('Danthalapalle'),
('Chinnagudur'),
('Bayyaram	'),
('Garla	'),
('Gangaram	'),
('Kothaguda	'),
('Gudur	'),
('Dornakal	'),
('Kesamudram	'),
('Kuravi	'),
('Mahabubabad	');

-- --------------------------------------------------------

--
-- Table structure for table `mahabubnagar`
--

CREATE TABLE IF NOT EXISTS `mahabubnagar` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahabubnagar`
--

INSERT INTO `mahabubnagar` (`mandals`) VALUES
('Mahabubnagar_Urban'),
('Mahabubnagar_Rural'),
('Moosapet'),
('Utkoor'),
('Addakal'),
('Balanagar'),
('Bhoothpur	 	'),
('Chinna_Chinta_Kunta'),
('Damargidda	 	'),
(' Devarakadra'),
('Dhanwada'),
('Gandeed	 	'),
('Hanwada	 	'),
('Jadcherla	 	'),
('Koilkonda	 	'),
('Kosgi	 	'),
('Krishna	 	'),
('Maddur	 	'),
('Maganoor	 	'),
('Makthal	 	'),
('Marikal'),
('Midjil	 	'),
('Nawabpet		'),
('Rajapur'),
('Narayanpet'),
('Narva');

-- --------------------------------------------------------

--
-- Table structure for table `mancherial`
--

CREATE TABLE IF NOT EXISTS `mancherial` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mancherial`
--

INSERT INTO `mancherial` (`mandals`) VALUES
('Bheemini'),
('Kannepally'),
('Chennur'),
('Jaipur'),
('Bheemaram'),
('Kotapally'),
('Luxettipet'),
('Mancherial'),
('Naspur'),
('Hajipur'),
('Mandamarri'),
('Dandepally'),
('Jannaram'),
('Kasipet'),
('Bellampally'),
('Vemanpally'),
('Nennel'),
('Tandur');

-- --------------------------------------------------------

--
-- Table structure for table `medak`
--

CREATE TABLE IF NOT EXISTS `medak` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medak`
--

INSERT INTO `medak` (`mandals`) VALUES
('Medak'),
('Havelighanpur'),
('Shankarampet_Rural'),
('Ramayampet'),
('Nizampet'),
('Alladurg'),
('Regode'),
('Papannapet'),
('Shankarampet_Urban'),
('Tekmal'),
('Yeldurthy'),
('Shivampet'),
('Chegunta'),
('Narsingi'),
('Toopran'),
('Manoharabad'),
('Narsapur'),
('Kowdipally'),
('Kulcharam'),
('Chilipched');

-- --------------------------------------------------------

--
-- Table structure for table `medchal_malkajgiri`
--

CREATE TABLE IF NOT EXISTS `medchal_malkajgiri` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medchal_malkajgiri`
--

INSERT INTO `medchal_malkajgiri` (`mandals`) VALUES
('Alwal'),
('Uppal'),
('Bachupally'),
('Balanagar'),
('Dundigal'),
('Kukatpally'),
('Malkajgiri'),
('Quthbullapur'),
('Ghatkesar'),
('Kapra'),
('Keesara'),
('Medchal'),
('Medipally'),
('Shamirpet');

-- --------------------------------------------------------

--
-- Table structure for table `nagarkurnool`
--

CREATE TABLE IF NOT EXISTS `nagarkurnool` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nagarkurnool`
--

INSERT INTO `nagarkurnool` (`mandals`) VALUES
('Nagarkurnool'),
('Tadoor'),
('Pentlavelli'),
('Kollapur'),
('Kodair'),
('Kalwakurthy'),
('Urkonda'),
('Charakonda'),
('Vangoor'),
('Veldanda'),
('Achampe'),
('Padara'),
('Amrabad'),
('Bijinapally'),
('Thimmajipet'),
('Telkapally'),
('Peddakothapally'),
('Lingal'),
('Balmoor'),
('Uppununthala');

-- --------------------------------------------------------

--
-- Table structure for table `nalgonda`
--

CREATE TABLE IF NOT EXISTS `nalgonda` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nalgonda`
--

INSERT INTO `nalgonda` (`mandals`) VALUES
('Nalgonda	'),
('Munugode'),
('Miryalaguda	'),
('Devarakonda'),
('Narketpalli'),
('Vemulapalli	'),
('Kondamallepally'),
('chityala	'),
('Damaracherla	'),
('Pedda_Adiserla_Palle'),
('Kattangoor	'),
('Advidevulapally'),
('Gundlapalli_Dindi'),
('Nakerekal	'),
('Madugulapally'),
('Chandampet'),
('Kethepalli	'),
('Nidmanoor	'),
('Neredugommu'),
('Shali_Gouraram	'),
('Tripuraram	'),
('Nampalli'),
('Thipparthy'),
('Gurrampode'),
('Anumula_Halia'),
('Marriguda'),
('Kanagal	'),
('Tirumalagiri_Sagar'),
('Chinthapalli'),
('Chandur	'),
('Peddavoora	');

-- --------------------------------------------------------

--
-- Table structure for table `nirmal`
--

CREATE TABLE IF NOT EXISTS `nirmal` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nirmal`
--

INSERT INTO `nirmal` (`mandals`) VALUES
('Nirmal Rural'),
('Soan'),
('Dilawarpur'),
('Narsapur'),
('Kaddam_Peddur'),
('Dasturabad'),
('Khanapur'),
('Mamada'),
('Pembi'),
('Laxmanchanda'),
('Sarangapur'),
('Kubeer'),
('Kuntala'),
('Bhainsa'),
('Mudhole'),
('Basar'),
('Lokeshwaram'),
('Tanoor'),
('Nirmal');

-- --------------------------------------------------------

--
-- Table structure for table `nizamabad`
--

CREATE TABLE IF NOT EXISTS `nizamabad` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nizamabad`
--

INSERT INTO `nizamabad` (`mandals`) VALUES
('Bodhan'),
('Renjal'),
('Rudrur'),
('Kotagiri'),
('Varni'),
('Yepally'),
('Makloor'),
('Dichapally'),
('Dharapply'),
('Indalwai'),
('Mugpal'),
('Navipet'),
('Nizamabad_North'),
('Nizamabad_South'),
('Nizamabad_Rural'),
('Sirikonda'),
('Armoor'),
('Balkonda'),
('Bheemgal'),
('Yergatla'),
('Morthad'),
('Mupkal'),
('Jakranpally'),
('Kammarapally'),
('Vailpoor'),
('Mendora'),
('Nandipet');

-- --------------------------------------------------------

--
-- Table structure for table `peddapalli`
--

CREATE TABLE IF NOT EXISTS `peddapalli` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `peddapalli`
--

INSERT INTO `peddapalli` (`mandals`) VALUES
('Manthani'),
('Mutharam'),
('Sulthanabad'),
('Peddapalli'),
('Odela'),
('Julapalli'),
('Eligaid'),
('Dharmaram'),
('Ramagundam'),
('Ramagundam_Rural'),
('Palakurthy'),
('Srirampur'),
('Kamanpur'),
(' Ramagiri');

-- --------------------------------------------------------

--
-- Table structure for table `rajanna_sircilla`
--

CREATE TABLE IF NOT EXISTS `rajanna_sircilla` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rajanna_sircilla`
--

INSERT INTO `rajanna_sircilla` (`mandals`) VALUES
('Sircilla'),
('Konaraopet'),
('Thangallapalli'),
('Gambhiraopet'),
('Vemulawada'),
(' Vemulawada_Rural'),
('Chendurthi'),
('Boinpalli'),
('Yellareddypet'),
('Rudrangi'),
('Veernapalli'),
('Mustabad'),
('Illanthakunta');

-- --------------------------------------------------------

--
-- Table structure for table `rangareddy`
--

CREATE TABLE IF NOT EXISTS `rangareddy` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rangareddy`
--

INSERT INTO `rangareddy` (`mandals`) VALUES
('Chevella'),
('Saroornagar		'),
('Abdullapuramet	'),
('Amangal	'),
('Gandipet	'),
('Chowderguda'),
('Moinabad	'),
('Hayathnagar	'),
('Balapur	'),
('Rajendranagar	'),
('Farooqnagar'),
('Shahbad	'),
('Ibrahimpatnam	'),
('Kandukur	'),
('Serilingampally	'),
('Keshampeta'),
('Shankarpalle	'),
('Madgul	'),
('Kadthal	'),
('Shamshabad	'),
('Kondurg'),
('Manchal	'),
('Maheswaram		'),
('Kothur'),
('Yacharam	'),
('Talakondapalle		'),
('Nandigama');

-- --------------------------------------------------------

--
-- Table structure for table `rejectedschl`
--

CREATE TABLE IF NOT EXISTS `rejectedschl` (
  `sname` varchar(500) NOT NULL,
  `stype` varchar(100) NOT NULL,
  `sclass` varchar(30) NOT NULL,
  `sdist` varchar(30) NOT NULL,
  `smand` varchar(40) NOT NULL,
  `saddr` varchar(300) NOT NULL,
  `snum` varchar(100) NOT NULL,
  `smail` varchar(100) NOT NULL,
  `sip1` varchar(50) NOT NULL,
  `sip2` varchar(50) DEFAULT NULL,
  `sfile` varchar(200) NOT NULL,
  `Reason` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rejectedschl`
--

INSERT INTO `rejectedschl` (`sname`, `stype`, `sclass`, `sdist`, `smand`, `saddr`, `snum`, `smail`, `sip1`, `sip2`, `sfile`, `Reason`) VALUES
('Ghatkesar model School', 'private_SSC', 'seventh', 'Medchal_Malkajgiri', 'Ghatkesar', 'Opposite to Union Bank,GHatkesar', '9762786320', 'ghatkesar@gmail.com', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\AvSchlSys\\uploadFiles\\AES.pdf', 'illegal Document');

-- --------------------------------------------------------

--
-- Table structure for table `sangareddy`
--

CREATE TABLE IF NOT EXISTS `sangareddy` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sangareddy`
--

INSERT INTO `sangareddy` (`mandals`) VALUES
('Sangareddy'),
('Vatpally'),
('Kangti'),
('Manoor'),
('Nagilgidda'),
(' Narayankhed'),
('Sirgapoor'),
('Ameenpur'),
('Andole'),
('Gummadidala'),
('Hathnoora'),
('Jinnaram'),
('Kandi'),
('Kondapur'),
('Munipally'),
('Patancheru'),
('Pulkal'),
(' Ramchandrapuram'),
('Sadasivpet'),
('Kalher'),
(' Zaheerabad'),
('Raikode'),
('Jharasangam'),
('Kohir'),
(' Mogudampally'),
('Nyalkal');

-- --------------------------------------------------------

--
-- Table structure for table `schooldetails`
--

CREATE TABLE IF NOT EXISTS `schooldetails` (
  `sid` varchar(100) NOT NULL DEFAULT '',
  `spwd` varchar(100) DEFAULT NULL,
  `sname` varchar(100) NOT NULL,
  `stype` varchar(100) NOT NULL,
  `selclass` varchar(20) NOT NULL,
  `sdist` varchar(100) NOT NULL,
  `smandal` varchar(100) NOT NULL,
  `saddress` varchar(500) NOT NULL,
  `sofficeno` varchar(100) NOT NULL,
  `smail` varchar(200) NOT NULL,
  `sip1` varchar(100) NOT NULL,
  `sip2` varchar(100) DEFAULT NULL,
  `sauthfile` varchar(300) NOT NULL,
  `creation` date NOT NULL,
  `year` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schooldetails`
--

INSERT INTO `schooldetails` (`sid`, `spwd`, `sname`, `stype`, `selclass`, `sdist`, `smandal`, `saddress`, `sofficeno`, `smail`, `sip1`, `sip2`, `sauthfile`, `creation`, `year`) VALUES
('hyd16BIHS', 'SI26ZG7SIMW', 'Bhasyam International High School', 'private_ICSE', 'tenth', 'Hyderabad', 'Secunderabad', 'Near Paradise', '5632479827', 'bhasyam@gmail.com', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\registration.html', '2018-07-11', 0),
('jgl3MCHS', 'msr', 'Mount Carmel High School', 'private_SSC', 'tenth', 'Jagtial', 'Jagitial_Rural', 'Beside Karimnagar Road ,Dharur. ', '9870654321', 'chintusept19@gmail.com', '127.0.0.1', '192.168.0.7', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\AvSchlSys\\uploadFiles\\07-02-2018-17-50-25-41delfil.png', '2018-07-07', 0),
('srd1khs', 'srdk', 'krishnaveni high school', 'private_CBSE', 'tenth', 'Sangareddy', 'Sangareddy', 'ytufyigkubjnlk.', '9876543210k', 'krishnaveni@gmail.com', '192.168.0.6', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\AD_R_H_Reg.html', '2018-07-13', 0),
('srd1SCHS', '0VUM3HFM7SY', 'Sri Chaitanya High School', 'private_CBSE', 'tenth', 'Sangareddy', 'Sangareddy', 'In Pothureddypalli chourasta', '5736429720', 'chaitanya@gmail.com', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\AD_Reg.html\\', '2018-07-12', 0),
('srd1ZPHS', 'GU2T3HZQITS', 'Zilla Parishad High School', 'Govt', 'tenth', 'Sangareddy', 'Sangareddy', 'ty uyf uyfjv jy ', '9876543210', 'zillaparishadsang@gmail.com', '192.168.0.5', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\CHomepage.html', '2018-07-13', 0);

-- --------------------------------------------------------

--
-- Table structure for table `siddipet`
--

CREATE TABLE IF NOT EXISTS `siddipet` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siddipet`
--

INSERT INTO `siddipet` (`mandals`) VALUES
('Siddipet_Urban'),
('Maddur'),
('Siddipet_Rural'),
('Nangnoor'),
('Chinnakodur'),
('Thoguta'),
('Doultabad'),
('Mirdoddi'),
('Dubbak'),
('Cherial'),
('Komuravelli'),
('Gajwel'),
('Jagdevpur'),
('Kondapak'),
('Mulug'),
('Markook'),
('Wargal'),
('Raipole'),
('Husnabad'),
('Akkannapet'),
('Koheda'),
('Bejjanki');

-- --------------------------------------------------------

--
-- Table structure for table `suryapet`
--

CREATE TABLE IF NOT EXISTS `suryapet` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suryapet`
--

INSERT INTO `suryapet` (`mandals`) VALUES
('Ananthagiri'),
('Mallareddygudem'),
('Atmakur'),
('Chivvemla'),
('Jajireddygudem'),
('Mothey'),
('Nuthankal'),
('Suryapet'),
('Thirumalagiri'),
('Thungathurthy'),
('Garidepally'),
('Neredcherla'),
('Nagaram'),
('Maddirala'),
('Palakeedu'),
('Chilkur'),
('Huzurnagar'),
('Kodad'),
('Mattampally'),
('Mellachervu'),
('Munagala'),
('Nadigudem'),
('Penpahad');

-- --------------------------------------------------------

--
-- Table structure for table `unschooletails`
--

CREATE TABLE IF NOT EXISTS `unschooletails` (
  `sname` varchar(500) NOT NULL,
  `stype` varchar(100) NOT NULL,
  `sclass` varchar(30) NOT NULL,
  `sdist` varchar(30) NOT NULL,
  `smand` varchar(40) NOT NULL,
  `saddr` varchar(300) NOT NULL,
  `snum` varchar(100) NOT NULL,
  `smail` varchar(100) NOT NULL,
  `sip1` varchar(50) NOT NULL,
  `sip2` varchar(50) DEFAULT NULL,
  `sfile` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unschooletails`
--

INSERT INTO `unschooletails` (`sname`, `stype`, `sclass`, `sdist`, `smand`, `saddr`, `snum`, `smail`, `sip1`, `sip2`, `sfile`) VALUES
('qasc', 'Govt', 'fifth', 'Nagarkurnool', 'Balmoor', 'qasqaef', '12343', 'ascvfb@gmail.com', '192.168.0.5', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\Admin_Login.html'),
('hello', 'Govt', 'fifth', 'Jagtial', 'Jagitial_Rural', 'sacfvsfxvb', '738403', 'bskcz@gmail.com', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp3\\wtpwebapps\\AvSchlSys\\schoolFiles\\New Text Document (2).txt'),
('ryctuvjyhkb', 'Govt', 'fifth', 'Nizamabad', 'Balkonda', 'rhctgjvhb', '46567', 'cgjvhkbj@gmail.com', '4567586', '', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp3\\wtpwebapps\\AvSchlSys\\schoolFiles\\2018-07-12 (8).png'),
('Jagruthi high school', 'Govt_girls', 'seventh', 'Sangareddy', 'Sangareddy', 'tcjufykvgubljkn.', '9876540987', 'jagrut@gmail.com', '192.168.0.22', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\AdminHome.html'),
('millinuum high school', 'private_SSC', 'tenth', 'Warangal_Urban', ' Hanamkonda', 'mucharla,hanmkona', '23144422', 'mhs@scc.cin', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp3\\wtpwebapps\\AvSchlSys\\schoolFiles\\10.png'),
('Narayana High School', 'private_CBSE', 'tenth', 'Karimnagar', 'Karimnagar', 'cytjv kb ', '6565686365', 'narayana@gmail.com', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\Admin_Sign_Up.html'),
('Narayana High School', 'private_CBSE', 'tenth', 'Karimnagar', 'Manakondur', 'cytjv kb ', '6565686365', 'narayanaaa@gmail.com', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\Admin_Sign_Up.html'),
('Narayana High School', 'private_CBSE', 'tenth', 'Karimnagar', 'Gangadhara', 'cytjv kb ', '6565686365', 'narayauygee@gmail.com', '192.168.0.7', '127.0.0.1', 'D:\\eclipse\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp2\\wtpwebapps\\AvSchlSys\\uploadFiles\\Admin_Sign_Up.html');

-- --------------------------------------------------------

--
-- Table structure for table `vikarabad`
--

CREATE TABLE IF NOT EXISTS `vikarabad` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vikarabad`
--

INSERT INTO `vikarabad` (`mandals`) VALUES
('Basheerabad'),
('Vikarabad'),
('Bommaraspet'),
('Doulthabad'),
('Kodangal'),
('Peddemul'),
('Tandur'),
('Yelal'),
('Kulkacherla'),
('Doma'),
(' Dharur'),
('Bantwaram'),
('Kotepally'),
('Marpalle'),
('Mominpet'),
('Nawabpet'),
('Pudur'),
('Pargi');

-- --------------------------------------------------------

--
-- Table structure for table `wanaparthy`
--

CREATE TABLE IF NOT EXISTS `wanaparthy` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wanaparthy`
--

INSERT INTO `wanaparthy` (`mandals`) VALUES
('Veepanagandla'),
('Wanaparthy'),
('Amarachintha'),
('Atmakur'),
('Chinnambavi'),
('Ghanpoor'),
('Gopalpeta'),
('Kothakota'),
('Madanapur'),
('Pangal'),
('Pebbair'),
('Peddamandadi'),
('Revally'),
('Srirangapur');

-- --------------------------------------------------------

--
-- Table structure for table `warangal_rural`
--

CREATE TABLE IF NOT EXISTS `warangal_rural` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `warangal_rural`
--

INSERT INTO `warangal_rural` (`mandals`) VALUES
(' Geesugonda'),
('Nekkonda'),
('Damera'),
('Atmakur'),
('Parkal'),
('Parvathagiri'),
('Rayaparthy'),
('Sangem'),
('Shayampet'),
('Wardhannapet'),
('Chennaraopet'),
('Duggondi'),
('Khanapur'),
('Narsampet'),
('Nallabelly');

-- --------------------------------------------------------

--
-- Table structure for table `warangal_urban`
--

CREATE TABLE IF NOT EXISTS `warangal_urban` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `warangal_urban`
--

INSERT INTO `warangal_urban` (`mandals`) VALUES
(' Hanamkonda'),
('Warangal'),
('Bheemadevarpalli'),
('Dharmasagar'),
('Elkathurthy'),
('Inavole'),
('Hasanparthy'),
('Kamalapur'),
('Kazipet'),
('Khila_Warangal'),
('Velair');

-- --------------------------------------------------------

--
-- Table structure for table `yadadri_bhuvanagiri`
--

CREATE TABLE IF NOT EXISTS `yadadri_bhuvanagiri` (
  `mandals` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `yadadri_bhuvanagiri`
--

INSERT INTO `yadadri_bhuvanagiri` (`mandals`) VALUES
('Addaguduru'),
('Valigonda'),
('Alair'),
('Atmakur_M'),
('Bibinagar'),
('Bhongir'),
('Bommalaramaram'),
('Motakondur'),
('Mothkur'),
('Rajapet'),
('Turkapally'),
('Yadagirigutta'),
('Bhoodan_Pochampally'),
('Choutuppal'),
('Ramannapet'),
('Narayanpur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic`
--
ALTER TABLE `academic`
 ADD PRIMARY KEY (`date`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`admid`);

--
-- Indexes for table `linkdetails`
--
ALTER TABLE `linkdetails`
 ADD PRIMARY KEY (`uuid`);

--
-- Indexes for table `linkstudent`
--
ALTER TABLE `linkstudent`
 ADD PRIMARY KEY (`aadhar`);

--
-- Indexes for table `rejectedschl`
--
ALTER TABLE `rejectedschl`
 ADD PRIMARY KEY (`smail`);

--
-- Indexes for table `schooldetails`
--
ALTER TABLE `schooldetails`
 ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `unschooletails`
--
ALTER TABLE `unschooletails`
 ADD PRIMARY KEY (`smail`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
